/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.2-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: mapa_relacional
-- ------------------------------------------------------
-- Server version	11.4.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `acessos_aplicacao`
--

DROP TABLE IF EXISTS `acessos_aplicacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acessos_aplicacao` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `aplicacao_participante_id` bigint(20) unsigned NOT NULL,
  `token_hash` char(64) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'ATIVO',
  `enviado_em` datetime DEFAULT NULL,
  `primeiro_acesso_em` datetime DEFAULT NULL,
  `ultimo_acesso_em` datetime DEFAULT NULL,
  `concluido_em` datetime DEFAULT NULL,
  `revogado_em` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_acessos_participante` (`aplicacao_participante_id`),
  UNIQUE KEY `uq_acessos_token_hash` (`token_hash`),
  KEY `idx_acessos_status` (`status`),
  CONSTRAINT `fk_acessos_aplicacao_participante` FOREIGN KEY (`aplicacao_participante_id`) REFERENCES `aplicacao_participantes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acessos_aplicacao`
--

LOCK TABLES `acessos_aplicacao` WRITE;
/*!40000 ALTER TABLE `acessos_aplicacao` DISABLE KEYS */;
INSERT INTO `acessos_aplicacao` VALUES
(1,1,'708842034400cad646c2b1ad2863b487cce561214acbc22d7b8fd8a4525709bf','CONCLUIDO','2026-10-05 05:29:36','2026-10-05 05:30:24','2026-10-05 05:32:27','2026-10-05 05:32:27',NULL,'2026-10-05 08:29:34','2026-10-05 08:32:27'),
(2,2,'e3d550cc55505829c58c988a6944215fdff7f1c379755f41d1cd04db48c021a9','CONCLUIDO','2026-10-05 05:29:36','2026-10-05 05:32:43','2026-10-05 05:33:46','2026-10-05 05:33:46',NULL,'2026-10-05 08:29:34','2026-10-05 08:33:46'),
(3,3,'9ad173a968a4737b47c5a0a80ef854215feb831d6e2f5907e94c0d2b5dfae18a','CONCLUIDO','2026-10-05 06:22:31','2026-10-05 06:23:13','2026-10-05 06:32:20','2026-10-05 06:32:20',NULL,'2026-10-05 09:22:30','2026-10-05 09:32:20'),
(4,4,'7ace4141e847b6ae89231d64683776f26ece8a2d7ec5a3d66ae3bcdf5073cfe1','CONCLUIDO','2026-10-05 06:34:58','2026-10-05 06:35:53','2026-10-05 06:36:47','2026-10-05 06:36:47',NULL,'2026-10-05 09:22:30','2026-10-05 09:36:47'),
(5,5,'8f598ae099635781b66440d416889f7b8cbf35af82c09e4db478010bdba81994','ATIVO','2026-10-05 07:13:39','2026-10-05 07:13:54','2026-10-05 07:14:05',NULL,NULL,'2026-10-05 10:13:37','2026-10-05 10:14:05'),
(6,6,'e6063a123ef46c2ceb1796666f8fad65b2477db76afaf783c380d83646307ff8','ATIVO','2026-10-05 07:13:39',NULL,NULL,NULL,NULL,'2026-10-05 10:13:37','2026-10-05 10:13:39'),
(7,7,'d19be72565b27e215c4004dffbe411d30b80e8863f53ecbe2bb4ff065dfbd13e','ATIVO','2026-10-05 07:22:33','2026-10-05 07:23:11','2026-10-05 07:23:19',NULL,NULL,'2026-10-05 10:22:32','2026-10-05 10:23:19'),
(8,8,'c883c2f95c6a6105e46a6ae4adea16c1ccccf2e1301679365ccdfc27b41b8f60','ATIVO','2026-10-05 07:22:33',NULL,NULL,NULL,NULL,'2026-10-05 10:22:32','2026-10-05 10:22:33'),
(9,9,'f298d381ef867a3e3bce8c3c02093c4c70650b628634249b5378e7eaf3c9b571','CONCLUIDO','2026-10-05 07:42:03','2026-10-05 07:43:13','2026-10-05 07:43:37','2026-10-05 07:43:37',NULL,'2026-10-05 10:42:02','2026-10-05 10:43:37'),
(10,10,'a35939de44febdd6b2b6156e9544825ac91d5ede8559cbd0b890a7eb9b20e06a','CONCLUIDO','2026-10-05 07:42:03','2026-10-05 07:43:51','2026-10-05 07:44:10','2026-10-05 07:44:10',NULL,'2026-10-05 10:42:02','2026-10-05 10:44:10');
/*!40000 ALTER TABLE `acessos_aplicacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alternativas`
--

DROP TABLE IF EXISTS `alternativas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alternativas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` bigint(20) unsigned NOT NULL,
  `valor` varchar(100) NOT NULL,
  `rotulo` varchar(255) NOT NULL,
  `ordem` int(10) unsigned NOT NULL DEFAULT 0,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_alternativas_item_valor` (`item_id`,`valor`),
  KEY `idx_alternativas_item_ordem` (`item_id`,`ordem`),
  CONSTRAINT `fk_alternativas_item` FOREIGN KEY (`item_id`) REFERENCES `itens` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alternativas`
--

LOCK TABLES `alternativas` WRITE;
/*!40000 ALTER TABLE `alternativas` DISABLE KEYS */;
INSERT INTO `alternativas` VALUES
(1,10,'BOM','Bom',1,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(2,7,'BOM','Bom',1,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(3,11,'BOM','Bom',1,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(4,9,'BOM','Bom',1,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(5,8,'BOM','Bom',1,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(6,2,'BOM','Bom',1,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(7,1,'BOM','Bom',1,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(8,4,'BOM','Bom',1,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(9,6,'BOM','Bom',1,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(10,5,'BOM','Bom',1,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(11,14,'BOM','Bom',1,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(12,15,'BOM','Bom',1,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(13,13,'BOM','Bom',1,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(14,12,'BOM','Bom',1,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(15,3,'BOM','Bom',1,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(16,10,'REGULAR','Regular',2,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(17,7,'REGULAR','Regular',2,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(18,11,'REGULAR','Regular',2,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(19,9,'REGULAR','Regular',2,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(20,8,'REGULAR','Regular',2,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(21,2,'REGULAR','Regular',2,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(22,1,'REGULAR','Regular',2,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(23,4,'REGULAR','Regular',2,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(24,6,'REGULAR','Regular',2,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(25,5,'REGULAR','Regular',2,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(26,14,'REGULAR','Regular',2,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(27,15,'REGULAR','Regular',2,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(28,13,'REGULAR','Regular',2,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(29,12,'REGULAR','Regular',2,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(30,3,'REGULAR','Regular',2,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(31,10,'FRACO','Fraco',3,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(32,7,'FRACO','Fraco',3,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(33,11,'FRACO','Fraco',3,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(34,9,'FRACO','Fraco',3,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(35,8,'FRACO','Fraco',3,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(36,2,'FRACO','Fraco',3,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(37,1,'FRACO','Fraco',3,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(38,4,'FRACO','Fraco',3,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(39,6,'FRACO','Fraco',3,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(40,5,'FRACO','Fraco',3,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(41,14,'FRACO','Fraco',3,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(42,15,'FRACO','Fraco',3,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(43,13,'FRACO','Fraco',3,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(44,12,'FRACO','Fraco',3,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(45,3,'FRACO','Fraco',3,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(65,35,'1','Nunca',1,1,'2026-10-05 10:17:41','2026-10-05 10:17:41'),
(66,35,'2','às vezes',2,1,'2026-10-05 10:18:02','2026-10-05 10:18:02'),
(67,35,'3','Sempre',3,1,'2026-10-05 10:18:13','2026-10-05 10:18:13'),
(68,36,'1','23',1,1,'2026-10-05 10:19:39','2026-10-05 10:19:39'),
(69,36,'2','24',2,1,'2026-10-05 10:19:49','2026-10-05 10:19:49'),
(70,36,'3','25',3,1,'2026-10-05 10:19:55','2026-10-05 10:19:55'),
(71,37,'1','Sempre',1,1,'2026-10-05 10:38:07','2026-10-05 10:38:07'),
(72,37,'2','às vezes',2,1,'2026-10-05 10:38:19','2026-10-05 10:38:19'),
(73,37,'3','Nunca',3,1,'2026-10-05 10:38:31','2026-10-05 10:38:31');
/*!40000 ALTER TABLE `alternativas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aplicacao_itens_excluidos`
--

DROP TABLE IF EXISTS `aplicacao_itens_excluidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aplicacao_itens_excluidos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `aplicacao_id` bigint(20) unsigned NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `marcado_por_participante_id` bigint(20) unsigned NOT NULL,
  `motivo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_aplicacao_item_excluido` (`aplicacao_id`,`item_id`),
  KEY `idx_itens_excluidos_participante` (`marcado_por_participante_id`),
  KEY `fk_itens_excluidos_item` (`item_id`),
  CONSTRAINT `fk_itens_excluidos_aplicacao` FOREIGN KEY (`aplicacao_id`) REFERENCES `aplicacoes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_itens_excluidos_item` FOREIGN KEY (`item_id`) REFERENCES `itens` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_itens_excluidos_participante` FOREIGN KEY (`marcado_por_participante_id`) REFERENCES `aplicacao_participantes` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aplicacao_itens_excluidos`
--

LOCK TABLES `aplicacao_itens_excluidos` WRITE;
/*!40000 ALTER TABLE `aplicacao_itens_excluidos` DISABLE KEYS */;
/*!40000 ALTER TABLE `aplicacao_itens_excluidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aplicacao_participantes`
--

DROP TABLE IF EXISTS `aplicacao_participantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aplicacao_participantes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `aplicacao_id` bigint(20) unsigned NOT NULL,
  `pessoa_id` bigint(20) unsigned DEFAULT NULL,
  `lado` char(1) NOT NULL,
  `nome_snapshot` varchar(150) DEFAULT NULL,
  `idade_snapshot` smallint(5) unsigned DEFAULT NULL,
  `genero_snapshot` varchar(30) DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'PENDENTE',
  `iniciou_em` datetime DEFAULT NULL,
  `concluiu_em` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_aplicacao_participante_lado` (`aplicacao_id`,`lado`),
  UNIQUE KEY `uq_aplicacao_participante_pessoa` (`aplicacao_id`,`pessoa_id`),
  KEY `idx_aplicacao_participantes_pessoa` (`pessoa_id`),
  KEY `idx_aplicacao_participantes_status` (`status`),
  CONSTRAINT `fk_aplicacao_participantes_aplicacao` FOREIGN KEY (`aplicacao_id`) REFERENCES `aplicacoes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_aplicacao_participantes_pessoa` FOREIGN KEY (`pessoa_id`) REFERENCES `pessoas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_aplicacao_participantes_lado` CHECK (`lado` in ('A','B'))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aplicacao_participantes`
--

LOCK TABLES `aplicacao_participantes` WRITE;
/*!40000 ALTER TABLE `aplicacao_participantes` DISABLE KEYS */;
INSERT INTO `aplicacao_participantes` VALUES
(1,1,NULL,'A','João',45,'Masculino','CONCLUIDO','2026-10-05 05:30:41','2026-10-05 05:32:27','2026-10-05 08:29:34','2026-10-05 08:32:27'),
(2,1,NULL,'B','Maria',44,'Feminino','CONCLUIDO','2026-10-05 05:32:57','2026-10-05 05:33:46','2026-10-05 08:29:34','2026-10-05 08:33:46'),
(3,2,NULL,'A','José',45,'Masculino','CONCLUIDO','2026-10-05 06:28:16','2026-10-05 06:32:20','2026-10-05 09:22:30','2026-10-05 09:32:20'),
(4,2,NULL,'B','Cláudia',43,'Feminino','CONCLUIDO','2026-10-05 06:36:01','2026-10-05 06:36:47','2026-10-05 09:22:30','2026-10-05 09:36:47'),
(5,3,NULL,'A','Pedro',9,'Masculino','EM_ANDAMENTO','2026-10-05 07:14:05',NULL,'2026-10-05 10:13:37','2026-10-05 10:14:05'),
(6,3,NULL,'B','Léo',NULL,NULL,'PENDENTE',NULL,NULL,'2026-10-05 10:13:37','2026-10-05 10:13:37'),
(7,4,NULL,'A','Jose',10,'Masculino','EM_ANDAMENTO','2026-10-05 07:23:19',NULL,'2026-10-05 10:22:32','2026-10-05 10:23:19'),
(8,4,NULL,'B','Carlos',NULL,NULL,'PENDENTE',NULL,NULL,'2026-10-05 10:22:32','2026-10-05 10:22:32'),
(9,5,NULL,'A','Mário',11,'Masculino','CONCLUIDO','2026-10-05 07:43:20','2026-10-05 07:43:37','2026-10-05 10:42:02','2026-10-05 10:43:37'),
(10,5,NULL,'B','Carlitos',12,'Masculino','CONCLUIDO','2026-10-05 07:44:00','2026-10-05 07:44:10','2026-10-05 10:42:02','2026-10-05 10:44:10');
/*!40000 ALTER TABLE `aplicacao_participantes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aplicacoes`
--

DROP TABLE IF EXISTS `aplicacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aplicacoes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profissional_id` bigint(20) unsigned NOT NULL,
  `vinculo_id` bigint(20) unsigned DEFAULT NULL,
  `instrumento_versao_id` bigint(20) unsigned NOT NULL,
  `email_contato` varchar(190) NOT NULL,
  `tipo_vinculo_snapshot` varchar(50) NOT NULL,
  `duracao_vinculo_texto` varchar(100) DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'RASCUNHO',
  `enviado_em` datetime DEFAULT NULL,
  `iniciada_em` datetime DEFAULT NULL,
  `concluida_em` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_aplicacoes_profissional` (`profissional_id`),
  KEY `idx_aplicacoes_vinculo` (`vinculo_id`),
  KEY `idx_aplicacoes_versao` (`instrumento_versao_id`),
  KEY `idx_aplicacoes_email` (`email_contato`),
  KEY `idx_aplicacoes_status` (`status`),
  CONSTRAINT `fk_aplicacoes_instrumento_versao` FOREIGN KEY (`instrumento_versao_id`) REFERENCES `instrumento_versoes` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_aplicacoes_profissional` FOREIGN KEY (`profissional_id`) REFERENCES `profissionais` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_aplicacoes_vinculo` FOREIGN KEY (`vinculo_id`) REFERENCES `vinculos` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aplicacoes`
--

LOCK TABLES `aplicacoes` WRITE;
/*!40000 ALTER TABLE `aplicacoes` DISABLE KEYS */;
INSERT INTO `aplicacoes` VALUES
(1,1,NULL,1,'gidenilson@gmail.com','CASAL','12','CONCLUIDA','2026-10-05 05:29:36','2026-10-05 05:30:41','2026-10-05 05:33:46','2026-10-05 08:29:34','2026-10-05 08:33:46'),
(2,1,NULL,1,'gidenilson@gmail.com','CASAL','10','CONCLUIDA','2026-10-05 06:22:31','2026-10-05 06:28:16','2026-10-05 06:36:47','2026-10-05 09:22:30','2026-10-05 09:36:47'),
(3,1,NULL,2,'gidenilson@gmail.com','FAMILIAR','3','EM_ANDAMENTO','2026-10-05 07:13:39','2026-10-05 07:14:05',NULL,'2026-10-05 10:13:37','2026-10-05 10:14:05'),
(4,1,NULL,2,'gidenilson@gmail.com','AMIZADE','4','EM_ANDAMENTO','2026-10-05 07:22:33','2026-10-05 07:23:19',NULL,'2026-10-05 10:22:32','2026-10-05 10:23:19'),
(5,1,NULL,5,'gidenilson@gmail.com','AMIZADE','1','CONCLUIDA','2026-10-05 07:42:03','2026-10-05 07:43:20','2026-10-05 07:44:10','2026-10-05 10:42:02','2026-10-05 10:44:10');
/*!40000 ALTER TABLE `aplicacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auditoria_eventos`
--

DROP TABLE IF EXISTS `auditoria_eventos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditoria_eventos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profissional_id` bigint(20) unsigned DEFAULT NULL,
  `ator_tipo` varchar(30) NOT NULL,
  `ator_id` bigint(20) unsigned DEFAULT NULL,
  `acao` varchar(80) NOT NULL,
  `entidade_tipo` varchar(80) DEFAULT NULL,
  `entidade_id` bigint(20) unsigned DEFAULT NULL,
  `contexto_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`contexto_json`)),
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_auditoria_profissional_data` (`profissional_id`,`created_at`),
  KEY `idx_auditoria_entidade` (`entidade_tipo`,`entidade_id`,`created_at`),
  KEY `idx_auditoria_acao_data` (`acao`,`created_at`),
  CONSTRAINT `fk_auditoria_profissional` FOREIGN KEY (`profissional_id`) REFERENCES `profissionais` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoria_eventos`
--

LOCK TABLES `auditoria_eventos` WRITE;
/*!40000 ALTER TABLE `auditoria_eventos` DISABLE KEYS */;
INSERT INTO `auditoria_eventos` VALUES
(1,1,'PUBLICO',NULL,'APLICACAO_PUBLICA_CRIADA','APLICACAO',1,'{\"instrumento_versao_id\":1,\"tipo_vinculo\":\"CASAL\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 08:29:36'),
(2,1,'PARTICIPANTE',1,'PARTICIPACAO_CONCLUIDA','APLICACAO',1,'{\"lado\":\"A\",\"aplicacao_concluida\":false}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 08:32:27'),
(3,1,'PARTICIPANTE',2,'PARTICIPACAO_CONCLUIDA','APLICACAO',1,'{\"lado\":\"B\",\"aplicacao_concluida\":true}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 08:33:46'),
(4,1,'PROFISSIONAL',1,'LOGIN_SUCESSO','PROFISSIONAL',1,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 08:34:59'),
(5,1,'PROFISSIONAL',1,'DEVOLUTIVA_RASCUNHO_SALVA','APLICACAO',1,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 08:38:02'),
(6,1,'PROFISSIONAL',1,'DEVOLUTIVA_LIBERADA','APLICACAO',1,'{\"email_enviado\":true}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 08:38:03'),
(7,1,'PUBLICO',NULL,'APLICACAO_PUBLICA_CRIADA','APLICACAO',2,'{\"instrumento_versao_id\":1,\"tipo_vinculo\":\"CASAL\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 09:22:31'),
(8,1,'PARTICIPANTE',3,'PARTICIPACAO_CONCLUIDA','APLICACAO',2,'{\"lado\":\"A\",\"aplicacao_concluida\":false}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 09:32:20'),
(9,1,'PROFISSIONAL',1,'LOGIN_SUCESSO','PROFISSIONAL',1,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 09:32:56'),
(10,1,'PROFISSIONAL',1,'LOGIN_SUCESSO','PROFISSIONAL',1,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 09:34:36'),
(11,1,'PROFISSIONAL',1,'ACESSO_PARTICIPANTE_REENVIADO','APLICACAO',2,'{\"lado\":\"B\",\"participante_id\":4}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 09:34:58'),
(12,1,'PARTICIPANTE',4,'PARTICIPACAO_CONCLUIDA','APLICACAO',2,'{\"lado\":\"B\",\"aplicacao_concluida\":true}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 09:36:47'),
(13,1,'PROFISSIONAL',1,'LOGIN_SUCESSO','PROFISSIONAL',1,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 09:37:03'),
(14,1,'PROFISSIONAL',1,'DEVOLUTIVA_RASCUNHO_SALVA','APLICACAO',2,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 09:38:10'),
(15,1,'PROFISSIONAL',1,'DEVOLUTIVA_RASCUNHO_SALVA','APLICACAO',2,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 09:40:08'),
(16,1,'PROFISSIONAL',1,'DEVOLUTIVA_LIBERADA','APLICACAO',2,'{\"email_enviado\":true}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 09:40:09'),
(17,1,'PROFISSIONAL',1,'VERSAO_CRIADA','INSTRUMENTO_VERSAO',2,'{\"instrumento_id\":2,\"numero_versao\":\"1\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 09:44:28'),
(18,1,'PROFISSIONAL',1,'VERSAO_PUBLICADA','INSTRUMENTO_VERSAO',2,'{\"instrumento_id\":2}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 10:03:23'),
(19,1,'PUBLICO',NULL,'APLICACAO_PUBLICA_CRIADA','APLICACAO',3,'{\"instrumento_versao_id\":2,\"tipo_vinculo\":\"FAMILIAR\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 10:13:39'),
(20,1,'PROFISSIONAL',1,'VERSAO_CRIADA','INSTRUMENTO_VERSAO',4,'{\"instrumento_id\":3,\"numero_versao\":\"1\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 10:15:46'),
(21,1,'PROFISSIONAL',1,'VERSAO_PUBLICADA','INSTRUMENTO_VERSAO',4,'{\"instrumento_id\":3}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 10:21:30'),
(22,1,'PUBLICO',NULL,'APLICACAO_PUBLICA_CRIADA','APLICACAO',4,'{\"instrumento_versao_id\":2,\"tipo_vinculo\":\"AMIZADE\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 10:22:33'),
(23,1,'PROFISSIONAL',1,'VERSAO_CRIADA','INSTRUMENTO_VERSAO',5,'{\"instrumento_id\":4,\"numero_versao\":\"1.0\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 10:30:46'),
(24,1,'PROFISSIONAL',1,'LOGIN_SUCESSO','PROFISSIONAL',1,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 10:33:20'),
(25,1,'PROFISSIONAL',1,'VERSAO_PUBLICADA','INSTRUMENTO_VERSAO',5,'{\"instrumento_id\":4}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 10:40:32'),
(26,1,'PUBLICO',NULL,'APLICACAO_PUBLICA_CRIADA','APLICACAO',5,'{\"instrumento_versao_id\":5,\"tipo_vinculo\":\"AMIZADE\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 10:42:03'),
(27,1,'PARTICIPANTE',9,'PARTICIPACAO_CONCLUIDA','APLICACAO',5,'{\"lado\":\"A\",\"aplicacao_concluida\":false}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 10:43:37'),
(28,1,'PARTICIPANTE',10,'PARTICIPACAO_CONCLUIDA','APLICACAO',5,'{\"lado\":\"B\",\"aplicacao_concluida\":true}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 10:44:10'),
(29,1,'PROFISSIONAL',1,'DEVOLUTIVA_RASCUNHO_SALVA','APLICACAO',5,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 10:48:20'),
(30,1,'PROFISSIONAL',1,'DEVOLUTIVA_LIBERADA','APLICACAO',5,'{\"email_enviado\":true}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 10:48:22'),
(31,1,'PROFISSIONAL',1,'LOGIN_SUCESSO','PROFISSIONAL',1,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 11:00:10'),
(32,1,'PROFISSIONAL',1,'SITE_IMAGEM_ENVIADA','PROFISSIONAL',1,'{\"mime\":\"image/png\",\"tamanho_bytes\":2103450}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 11:00:42'),
(33,1,'PROFISSIONAL',1,'PERFIL_ATUALIZADO','PROFISSIONAL',1,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 11:00:45'),
(34,1,'PROFISSIONAL',1,'PERFIL_ATUALIZADO','PROFISSIONAL',1,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 11:01:09'),
(35,1,'PROFISSIONAL',1,'SITE_BLOCO_CRIADO','SITE_BLOCO',1,'{\"tipo\":\"APRESENTACAO\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 11:03:14'),
(36,1,'PROFISSIONAL',1,'SITE_BLOCO_CRIADO','SITE_BLOCO',2,'{\"tipo\":\"TEXTO\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 11:04:18'),
(37,1,'PROFISSIONAL',1,'LOGIN_SUCESSO','PROFISSIONAL',1,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 11:06:56'),
(38,1,'PROFISSIONAL',1,'PERFIL_ATUALIZADO','PROFISSIONAL',1,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 11:08:33'),
(39,1,'PROFISSIONAL',1,'SITE_BLOCO_ATUALIZADO','SITE_BLOCO',1,'{\"tipo\":\"APRESENTACAO\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 11:09:40'),
(40,1,'PROFISSIONAL',1,'PERFIL_ATUALIZADO','PROFISSIONAL',1,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 11:10:49');
/*!40000 ALTER TABLE `auditoria_eventos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comparacoes`
--

DROP TABLE IF EXISTS `comparacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comparacoes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `aplicacao_id` bigint(20) unsigned NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `sentido` varchar(30) NOT NULL,
  `resposta_percebida_id` bigint(20) unsigned DEFAULT NULL,
  `resposta_autorreferida_id` bigint(20) unsigned DEFAULT NULL,
  `comparavel` tinyint(1) NOT NULL DEFAULT 0,
  `coincide` tinyint(1) DEFAULT NULL,
  `motivo_nao_comparavel` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_comparacoes_aplicacao_item_sentido` (`aplicacao_id`,`item_id`,`sentido`),
  KEY `idx_comparacoes_aplicacao_sentido` (`aplicacao_id`,`sentido`),
  KEY `idx_comparacoes_item` (`item_id`),
  KEY `idx_comparacoes_resposta_percebida` (`resposta_percebida_id`),
  KEY `idx_comparacoes_resposta_autorreferida` (`resposta_autorreferida_id`),
  CONSTRAINT `fk_comparacoes_aplicacao` FOREIGN KEY (`aplicacao_id`) REFERENCES `aplicacoes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_comparacoes_item` FOREIGN KEY (`item_id`) REFERENCES `itens` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_comparacoes_resposta_autorreferida` FOREIGN KEY (`resposta_autorreferida_id`) REFERENCES `respostas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_comparacoes_resposta_percebida` FOREIGN KEY (`resposta_percebida_id`) REFERENCES `respostas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_comparacoes_sentido` CHECK (`sentido` in ('A_SOBRE_B','B_SOBRE_A')),
  CONSTRAINT `chk_comparacoes_coincide` CHECK (`coincide` is null or `coincide` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comparacoes`
--

LOCK TABLES `comparacoes` WRITE;
/*!40000 ALTER TABLE `comparacoes` DISABLE KEYS */;
INSERT INTO `comparacoes` VALUES
(1,1,1,'A_SOBRE_B',2,32,1,1,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(2,1,1,'B_SOBRE_A',33,1,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(3,1,2,'A_SOBRE_B',4,34,1,1,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(4,1,2,'B_SOBRE_A',35,3,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(5,1,3,'A_SOBRE_B',6,36,1,1,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(6,1,3,'B_SOBRE_A',37,5,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(7,1,4,'A_SOBRE_B',8,38,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(8,1,4,'B_SOBRE_A',39,7,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(9,1,5,'A_SOBRE_B',11,40,1,1,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(10,1,5,'B_SOBRE_A',41,10,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(11,1,6,'A_SOBRE_B',13,42,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(12,1,6,'B_SOBRE_A',43,12,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(13,1,7,'A_SOBRE_B',15,44,1,1,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(14,1,7,'B_SOBRE_A',45,14,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(15,1,8,'A_SOBRE_B',17,46,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(16,1,8,'B_SOBRE_A',47,16,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(17,1,9,'A_SOBRE_B',19,48,1,1,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(18,1,9,'B_SOBRE_A',49,18,1,1,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(19,1,10,'A_SOBRE_B',21,50,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(20,1,10,'B_SOBRE_A',51,20,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(21,1,11,'A_SOBRE_B',23,52,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(22,1,11,'B_SOBRE_A',53,22,1,1,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(23,1,12,'A_SOBRE_B',25,54,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(24,1,12,'B_SOBRE_A',55,24,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(25,1,13,'A_SOBRE_B',27,56,1,1,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(26,1,13,'B_SOBRE_A',57,26,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(27,1,14,'A_SOBRE_B',29,58,1,1,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(28,1,14,'B_SOBRE_A',59,28,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(29,1,15,'A_SOBRE_B',31,60,1,1,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(30,1,15,'B_SOBRE_A',61,30,1,0,NULL,'2026-10-05 08:33:46','2026-10-05 08:33:46'),
(31,2,1,'A_SOBRE_B',63,92,1,1,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(32,2,1,'B_SOBRE_A',93,62,1,1,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(33,2,2,'A_SOBRE_B',65,94,1,0,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(34,2,2,'B_SOBRE_A',95,64,1,0,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(35,2,3,'A_SOBRE_B',67,96,1,1,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(36,2,3,'B_SOBRE_A',97,66,1,0,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(37,2,4,'A_SOBRE_B',68,98,1,1,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(38,2,4,'B_SOBRE_A',99,69,1,0,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(39,2,5,'A_SOBRE_B',71,100,1,1,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(40,2,5,'B_SOBRE_A',101,70,1,1,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(41,2,6,'A_SOBRE_B',73,102,1,0,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(42,2,6,'B_SOBRE_A',103,72,1,1,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(43,2,7,'A_SOBRE_B',75,104,1,0,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(44,2,7,'B_SOBRE_A',105,74,1,1,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(45,2,8,'A_SOBRE_B',77,106,1,1,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(46,2,8,'B_SOBRE_A',107,76,1,0,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(47,2,9,'A_SOBRE_B',79,108,1,1,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(48,2,9,'B_SOBRE_A',109,78,1,0,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(49,2,10,'A_SOBRE_B',81,110,1,0,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(50,2,10,'B_SOBRE_A',111,80,1,0,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(51,2,11,'A_SOBRE_B',83,112,1,0,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(52,2,11,'B_SOBRE_A',113,82,1,0,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(53,2,12,'A_SOBRE_B',85,114,1,1,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(54,2,12,'B_SOBRE_A',115,84,1,0,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(55,2,13,'A_SOBRE_B',87,116,1,0,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(56,2,13,'B_SOBRE_A',117,86,1,0,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(57,2,14,'A_SOBRE_B',89,118,1,1,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(58,2,14,'B_SOBRE_A',119,88,1,1,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(59,2,15,'A_SOBRE_B',91,120,1,0,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(60,2,15,'B_SOBRE_A',121,90,1,1,NULL,'2026-10-05 09:36:47','2026-10-05 09:36:47'),
(61,5,37,'A_SOBRE_B',123,124,1,1,NULL,'2026-10-05 10:44:10','2026-10-05 10:44:10'),
(62,5,37,'B_SOBRE_A',125,122,1,0,NULL,'2026-10-05 10:44:10','2026-10-05 10:44:10');
/*!40000 ALTER TABLE `comparacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devolutivas`
--

DROP TABLE IF EXISTS `devolutivas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devolutivas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `aplicacao_id` bigint(20) unsigned NOT NULL,
  `profissional_id` bigint(20) unsigned NOT NULL,
  `sintese` text DEFAULT NULL,
  `observacoes` text DEFAULT NULL,
  `comentario_profissional` text DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'RASCUNHO',
  `token_hash` char(64) DEFAULT NULL,
  `liberada_em` datetime DEFAULT NULL,
  `enviado_em` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_devolutivas_aplicacao` (`aplicacao_id`),
  UNIQUE KEY `uq_devolutivas_token_hash` (`token_hash`),
  KEY `idx_devolutivas_profissional_status` (`profissional_id`,`status`),
  CONSTRAINT `fk_devolutivas_aplicacao` FOREIGN KEY (`aplicacao_id`) REFERENCES `aplicacoes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_devolutivas_profissional` FOREIGN KEY (`profissional_id`) REFERENCES `profissionais` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `chk_devolutivas_status` CHECK (`status` in ('RASCUNHO','LIBERADA'))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devolutivas`
--

LOCK TABLES `devolutivas` WRITE;
/*!40000 ALTER TABLE `devolutivas` DISABLE KEYS */;
INSERT INTO `devolutivas` VALUES
(1,1,1,'Sintese geral','Pontos de atenção','Comentário profissional','LIBERADA','79bb6156f6fe68d87f0c799585ee697775fa8979b1f6b656fca55fc8114d5adc','2026-10-05 05:38:03','2026-10-05 05:38:03','2026-10-05 08:38:02','2026-10-05 08:38:03'),
(2,2,1,'hhfghfg','ryrtytry','rtyrtytytytrytryt','LIBERADA','f8758322e2ac8542c0336ab6399978b63198caf21bb1bd102a184e82ccb0d307','2026-10-05 06:40:09','2026-10-05 06:40:09','2026-10-05 09:38:10','2026-10-05 09:40:09'),
(4,5,1,'Lorem ipsum dolor sit amet consectetur adipiscing elit sociosqu, fermentum natoque magna varius ad leo at, commodo consequat sagittis vitae nisl posuere inceptos. Lacus quam tortor laoreet fermentum facilisis nibh dapibus dui ultricies porta, morbi ridiculus malesuada eget magna vel fringilla sem.','Eget montes ligula proin ridiculus risus mus porta augue nam, taciti dapibus purus class tellus vehicula nulla rhoncus litora sed, vulputate ac sociis dictumst lectus blandit luctus sociosqu. Nulla inceptos sed lectus ultrices quisque','Lacus quam tortor laoreet fermentum facilisis nibh dapibus dui ultricies porta, morbi ridiculus malesuada eget magna vel fringilla sem.','LIBERADA','02352c0e55a54827916313d43944983233b78c60b704f25005b273f3414f11e2','2026-10-05 07:48:22','2026-10-05 07:48:22','2026-10-05 10:48:20','2026-10-05 10:48:22');
/*!40000 ALTER TABLE `devolutivas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instrumento_versoes`
--

DROP TABLE IF EXISTS `instrumento_versoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instrumento_versoes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `instrumento_id` bigint(20) unsigned NOT NULL,
  `numero_versao` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'RASCUNHO',
  `publicado_em` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_instrumento_versao` (`instrumento_id`,`numero_versao`),
  KEY `idx_instrumento_versoes_status` (`status`),
  CONSTRAINT `fk_instrumento_versoes_instrumento` FOREIGN KEY (`instrumento_id`) REFERENCES `instrumentos` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instrumento_versoes`
--

LOCK TABLES `instrumento_versoes` WRITE;
/*!40000 ALTER TABLE `instrumento_versoes` DISABLE KEYS */;
INSERT INTO `instrumento_versoes` VALUES
(1,1,'1.0','PUBLICADA','2026-10-05 05:23:27','2026-10-05 08:23:27','2026-10-05 08:23:27'),
(2,2,'1','PUBLICADA','2026-10-05 07:03:23','2026-10-05 09:44:28','2026-10-05 10:03:23'),
(4,3,'1','PUBLICADA','2026-10-05 07:21:30','2026-10-05 10:15:46','2026-10-05 10:21:30'),
(5,4,'1.0','PUBLICADA','2026-10-05 07:40:32','2026-10-05 10:30:46','2026-10-05 10:40:32');
/*!40000 ALTER TABLE `instrumento_versoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instrumentos`
--

DROP TABLE IF EXISTS `instrumentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instrumentos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profissional_id` bigint(20) unsigned NOT NULL,
  `nome` varchar(180) NOT NULL,
  `descricao` text DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'RASCUNHO',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_instrumentos_profissional` (`profissional_id`),
  KEY `idx_instrumentos_status` (`status`),
  CONSTRAINT `fk_instrumentos_profissional` FOREIGN KEY (`profissional_id`) REFERENCES `profissionais` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instrumentos`
--

LOCK TABLES `instrumentos` WRITE;
/*!40000 ALTER TABLE `instrumentos` DISABLE KEYS */;
INSERT INTO `instrumentos` VALUES
(1,1,'Avaliação Conjugal','Teste de percepção a ser respondido separadamente pelos participantes. Cada pessoa avalia o que pensa sobre o relacionamento e o que imagina que o outro pensa. Depois, as percepções são comparadas e as respostas iguais contam como acertos. Este não é um teste absoluto e deve ser interpretado dentro da realidade, valores e contexto do relacionamento.','ATIVO','2026-10-05 08:23:27','2026-10-05 08:23:27'),
(2,1,'Avaliação de amizade','Este é um teste de avaliação de amizade','ATIVO','2026-10-05 09:44:03','2026-10-05 10:12:55'),
(3,1,'Nova amizade','Nova amizade','RASCUNHO','2026-10-05 10:15:30','2026-10-05 10:15:30'),
(4,1,'Amizade','Avaliação de amizade','ATIVO','2026-10-05 10:30:22','2026-10-05 10:30:22');
/*!40000 ALTER TABLE `instrumentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `itens`
--

DROP TABLE IF EXISTS `itens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `itens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `secao_id` bigint(20) unsigned NOT NULL,
  `codigo` varchar(80) NOT NULL,
  `texto` text NOT NULL,
  `tipo_resposta` varchar(40) NOT NULL,
  `ordem` int(10) unsigned NOT NULL DEFAULT 0,
  `permite_nao_se_aplica` tinyint(1) NOT NULL DEFAULT 0,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_itens_secao_codigo` (`secao_id`,`codigo`),
  KEY `idx_itens_secao_ordem` (`secao_id`,`ordem`),
  CONSTRAINT `fk_itens_secao` FOREIGN KEY (`secao_id`) REFERENCES `secoes` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itens`
--

LOCK TABLES `itens` WRITE;
/*!40000 ALTER TABLE `itens` DISABLE KEYS */;
INSERT INTO `itens` VALUES
(1,1,'COMUNICACAO','Comunicação','ESCOLHA_UNICA',1,0,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(2,1,'COMPANHEIRISMO','Companheirismo','ESCOLHA_UNICA',2,0,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(3,1,'RESPEITO_MUTUO','Respeito mútuo','ESCOLHA_UNICA',3,0,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(4,1,'DIVIDIR_ALEGRIAS','Dividir alegrias','ESCOLHA_UNICA',4,0,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(5,1,'DIVIDIR_TRISTEZAS','Dividir tristezas','ESCOLHA_UNICA',5,0,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(6,1,'DIVIDIR_PROBLEMAS','Dividir problemas','ESCOLHA_UNICA',6,0,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(7,1,'AFINIDADE_IDEIAS','Afinidade de idéias','ESCOLHA_UNICA',7,0,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(8,1,'AFINIDADE_VALORES_MORAIS','Afinidade de valores morais','ESCOLHA_UNICA',8,0,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(9,1,'AFINIDADE_RELIGIOSA_ESPIRITUAL','Afinidade religiosa/espiritual','ESCOLHA_UNICA',9,0,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(10,1,'AFINIDADE_FINANCEIRA_INVESTIMENTOS','Afinidade financeira/investimentos','ESCOLHA_UNICA',10,0,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(11,1,'AFINIDADE_INTELECTUAL','Afinidade intelectual','ESCOLHA_UNICA',11,0,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(12,1,'RELACIONAMENTO_SEXUAL','Relacionamento sexual','ESCOLHA_UNICA',12,0,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(13,1,'QUALIDADE_TEMPO','Qualidade de tempo gasto um com o outro','ESCOLHA_UNICA',13,0,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(14,1,'DIVISAO_TRABALHO_DOMESTICO','Divisão do trabalho doméstico','ESCOLHA_UNICA',14,0,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(15,1,'DIVISAO_TRABALHO_FILHOS_CUIDADOS','Divisão do trabalho com filhos/cuidados','ESCOLHA_UNICA',15,1,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(31,2,'ITEM_001','Brincamos muito','ESCOLHA_UNICA',1,0,1,'2026-10-05 09:59:48','2026-10-05 09:59:48'),
(32,2,'ITEM_002','Não gosto de matemática','ESCOLHA_UNICA',2,0,1,'2026-10-05 10:00:29','2026-10-05 10:00:29'),
(33,2,'ITEM_003','Gosto de português','ESCOLHA_UNICA',3,0,1,'2026-10-05 10:00:56','2026-10-05 10:00:56'),
(34,2,'ITEM_004','O professor de educação física é muito lento','ESCOLHA_UNICA',4,0,1,'2026-10-05 10:01:22','2026-10-05 10:01:22'),
(35,3,'ITEM_001','TExto da perguhta','ESCOLHA_UNICA',1,0,1,'2026-10-05 10:17:08','2026-10-05 10:17:08'),
(36,3,'ITEM_002','Quantos anos tem a professora Ritinha','NUMERICO',2,0,1,'2026-10-05 10:19:26','2026-10-05 10:19:26'),
(37,4,'ITEM_001','A professora Joana é boa em geografia?','ESCOLHA_UNICA',1,0,1,'2026-10-05 10:37:39','2026-10-05 10:37:39');
/*!40000 ALTER TABLE `itens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pessoas`
--

DROP TABLE IF EXISTS `pessoas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pessoas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profissional_id` bigint(20) unsigned NOT NULL,
  `nome` varchar(150) NOT NULL,
  `email` varchar(190) DEFAULT NULL,
  `telefone` varchar(30) DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `observacao_administrativa` text DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'ATIVO',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_pessoas_profissional` (`profissional_id`),
  KEY `idx_pessoas_email` (`email`),
  KEY `idx_pessoas_status` (`status`),
  CONSTRAINT `fk_pessoas_profissional` FOREIGN KEY (`profissional_id`) REFERENCES `profissionais` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pessoas`
--

LOCK TABLES `pessoas` WRITE;
/*!40000 ALTER TABLE `pessoas` DISABLE KEYS */;
/*!40000 ALTER TABLE `pessoas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profissionais`
--

DROP TABLE IF EXISTS `profissionais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profissionais` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) NOT NULL,
  `email` varchar(190) NOT NULL,
  `senha_hash` varchar(255) DEFAULT NULL,
  `telefone` varchar(30) DEFAULT NULL,
  `descricao` text DEFAULT NULL,
  `atuacao` text DEFAULT NULL,
  `foto_url` varchar(500) DEFAULT NULL,
  `logo_url` varchar(500) DEFAULT NULL,
  `dados_contato` text DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'ATIVO',
  `senha_alterada_em` datetime DEFAULT NULL,
  `ultimo_login_em` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_profissionais_email` (`email`),
  KEY `idx_profissionais_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profissionais`
--

LOCK TABLES `profissionais` WRITE;
/*!40000 ALTER TABLE `profissionais` DISABLE KEYS */;
INSERT INTO `profissionais` VALUES
(1,'Tânia Lopes Santiago','tanialopessantiago@gmail.com','$2y$10$iefrgyU6jbBxU9bQWKSsaOKHAPeuOcG5O1SL7ahSX/hf8lkoT2RTy','16997119152','A família é um sistema onde cada integrante possui recursos inatos ou adquiridos que são utilizados como \"ferramentas\" para a resolução de problemas e o processo terapêutico visa auxiliar a família no descobrimento dessas \"ferramentas\" individuais e grupais, para solucionar situações conflituosas. Esta visão sistêmica de resolução de conflitos também se aplica a empresas, escolas e a equipes de trabalho em geral.','Curae lacus arcu elementum blandit vestibulum tellus egestas eu mauris turpis, accumsan lacinia lectus velit ullamcorper sodales bibendum fusce imperdiet fermentum, potenti natoque semper pretium nullam et urna proin nostra.','http://localhost:8383/uploads/site/1/5681922dc8f0401f784411d83510260a.png','http://localhost:8383/uploads/site/1/c799eee3b445dd739559405f399bcb2d.png','Whatsapp: (16) 99791-4626 E-mail: tania.terapeutafamiliar@gmail.com','ATIVO','2026-10-03 19:18:54','2026-10-05 08:06:56','2026-10-03 16:00:21','2026-10-05 11:08:33');
/*!40000 ALTER TABLE `profissionais` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rate_limites`
--

DROP TABLE IF EXISTS `rate_limites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rate_limites` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `escopo` varchar(60) NOT NULL,
  `chave_hash` char(64) NOT NULL,
  `contador` int(10) unsigned NOT NULL DEFAULT 1,
  `janela_expira_em` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rate_limites_escopo_chave` (`escopo`,`chave_hash`),
  KEY `idx_rate_limites_expira` (`janela_expira_em`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rate_limites`
--

LOCK TABLES `rate_limites` WRITE;
/*!40000 ALTER TABLE `rate_limites` DISABLE KEYS */;
INSERT INTO `rate_limites` VALUES
(1,'public_evaluation_start_ip','52c43d0769cbab7054e76ce7e63468e01385357a83fbc0bfa9bf5430d6d9e7dd',1,'2026-10-05 07:57:02','2026-10-05 08:29:34','2026-10-05 10:42:02'),
(2,'public_evaluation_start_email','d63967174d75b8ae0c49dfcae2f5946b1442135f941835fe85f2c1ff46cb7229',1,'2026-10-05 07:57:02','2026-10-05 08:29:34','2026-10-05 10:42:02');
/*!40000 ALTER TABLE `rate_limites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `respostas`
--

DROP TABLE IF EXISTS `respostas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `respostas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `aplicacao_id` bigint(20) unsigned NOT NULL,
  `respondente_id` bigint(20) unsigned NOT NULL,
  `alvo_id` bigint(20) unsigned NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `alternativa_id` bigint(20) unsigned DEFAULT NULL,
  `valor_texto` text DEFAULT NULL,
  `valor_numero` decimal(18,6) DEFAULT NULL,
  `nao_se_aplica` tinyint(1) NOT NULL DEFAULT 0,
  `respondido_em` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_resposta_contexto` (`aplicacao_id`,`respondente_id`,`alvo_id`,`item_id`),
  KEY `idx_respostas_aplicacao_item` (`aplicacao_id`,`item_id`),
  KEY `idx_respostas_respondente` (`respondente_id`),
  KEY `idx_respostas_alvo` (`alvo_id`),
  KEY `idx_respostas_alternativa` (`alternativa_id`),
  KEY `fk_respostas_item` (`item_id`),
  CONSTRAINT `fk_respostas_alternativa` FOREIGN KEY (`alternativa_id`) REFERENCES `alternativas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_respostas_alvo` FOREIGN KEY (`alvo_id`) REFERENCES `aplicacao_participantes` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_respostas_aplicacao` FOREIGN KEY (`aplicacao_id`) REFERENCES `aplicacoes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_respostas_item` FOREIGN KEY (`item_id`) REFERENCES `itens` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_respostas_respondente` FOREIGN KEY (`respondente_id`) REFERENCES `aplicacao_participantes` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `respostas`
--

LOCK TABLES `respostas` WRITE;
/*!40000 ALTER TABLE `respostas` DISABLE KEYS */;
INSERT INTO `respostas` VALUES
(1,1,1,1,1,7,NULL,NULL,0,'2026-10-05 05:31:32','2026-10-05 08:31:32','2026-10-05 08:31:32'),
(2,1,1,2,1,7,NULL,NULL,0,'2026-10-05 05:31:34','2026-10-05 08:31:34','2026-10-05 08:31:34'),
(3,1,1,1,2,21,NULL,NULL,0,'2026-10-05 05:31:37','2026-10-05 08:31:37','2026-10-05 08:31:37'),
(4,1,1,2,2,6,NULL,NULL,0,'2026-10-05 05:31:38','2026-10-05 08:31:38','2026-10-05 08:31:38'),
(5,1,1,1,3,15,NULL,NULL,0,'2026-10-05 05:31:40','2026-10-05 08:31:40','2026-10-05 08:31:40'),
(6,1,1,2,3,30,NULL,NULL,0,'2026-10-05 05:31:42','2026-10-05 08:31:42','2026-10-05 08:31:42'),
(7,1,1,1,4,23,NULL,NULL,0,'2026-10-05 05:31:47','2026-10-05 08:31:44','2026-10-05 08:31:47'),
(8,1,1,2,4,8,NULL,NULL,0,'2026-10-05 05:31:44','2026-10-05 08:31:44','2026-10-05 08:31:44'),
(10,1,1,1,5,10,NULL,NULL,0,'2026-10-05 05:31:50','2026-10-05 08:31:50','2026-10-05 08:31:50'),
(11,1,1,2,5,25,NULL,NULL,0,'2026-10-05 05:31:51','2026-10-05 08:31:51','2026-10-05 08:31:51'),
(12,1,1,1,6,9,NULL,NULL,0,'2026-10-05 05:31:53','2026-10-05 08:31:53','2026-10-05 08:31:53'),
(13,1,1,2,6,39,NULL,NULL,0,'2026-10-05 05:31:54','2026-10-05 08:31:54','2026-10-05 08:31:54'),
(14,1,1,1,7,17,NULL,NULL,0,'2026-10-05 05:31:57','2026-10-05 08:31:57','2026-10-05 08:31:57'),
(15,1,1,2,7,2,NULL,NULL,0,'2026-10-05 05:31:58','2026-10-05 08:31:58','2026-10-05 08:31:58'),
(16,1,1,1,8,20,NULL,NULL,0,'2026-10-05 05:32:00','2026-10-05 08:32:00','2026-10-05 08:32:00'),
(17,1,1,2,8,20,NULL,NULL,0,'2026-10-05 05:32:01','2026-10-05 08:32:01','2026-10-05 08:32:01'),
(18,1,1,1,9,19,NULL,NULL,0,'2026-10-05 05:32:04','2026-10-05 08:32:04','2026-10-05 08:32:04'),
(19,1,1,2,9,19,NULL,NULL,0,'2026-10-05 05:32:05','2026-10-05 08:32:05','2026-10-05 08:32:05'),
(20,1,1,1,10,1,NULL,NULL,0,'2026-10-05 05:32:07','2026-10-05 08:32:07','2026-10-05 08:32:07'),
(21,1,1,2,10,16,NULL,NULL,0,'2026-10-05 05:32:08','2026-10-05 08:32:08','2026-10-05 08:32:08'),
(22,1,1,1,11,18,NULL,NULL,0,'2026-10-05 05:32:10','2026-10-05 08:32:10','2026-10-05 08:32:10'),
(23,1,1,2,11,18,NULL,NULL,0,'2026-10-05 05:32:11','2026-10-05 08:32:11','2026-10-05 08:32:11'),
(24,1,1,1,12,44,NULL,NULL,0,'2026-10-05 05:32:13','2026-10-05 08:32:13','2026-10-05 08:32:13'),
(25,1,1,2,12,44,NULL,NULL,0,'2026-10-05 05:32:14','2026-10-05 08:32:14','2026-10-05 08:32:14'),
(26,1,1,1,13,28,NULL,NULL,0,'2026-10-05 05:32:15','2026-10-05 08:32:15','2026-10-05 08:32:15'),
(27,1,1,2,13,13,NULL,NULL,0,'2026-10-05 05:32:16','2026-10-05 08:32:16','2026-10-05 08:32:16'),
(28,1,1,1,14,26,NULL,NULL,0,'2026-10-05 05:32:17','2026-10-05 08:32:17','2026-10-05 08:32:17'),
(29,1,1,2,14,26,NULL,NULL,0,'2026-10-05 05:32:18','2026-10-05 08:32:18','2026-10-05 08:32:18'),
(30,1,1,1,15,12,NULL,NULL,0,'2026-10-05 05:32:22','2026-10-05 08:32:22','2026-10-05 08:32:22'),
(31,1,1,2,15,12,NULL,NULL,0,'2026-10-05 05:32:23','2026-10-05 08:32:23','2026-10-05 08:32:23'),
(32,1,2,2,1,7,NULL,NULL,0,'2026-10-05 05:33:00','2026-10-05 08:33:00','2026-10-05 08:33:00'),
(33,1,2,1,1,22,NULL,NULL,0,'2026-10-05 05:33:01','2026-10-05 08:33:01','2026-10-05 08:33:01'),
(34,1,2,2,2,6,NULL,NULL,0,'2026-10-05 05:33:03','2026-10-05 08:33:03','2026-10-05 08:33:03'),
(35,1,2,1,2,6,NULL,NULL,0,'2026-10-05 05:33:03','2026-10-05 08:33:03','2026-10-05 08:33:03'),
(36,1,2,2,3,30,NULL,NULL,0,'2026-10-05 05:33:07','2026-10-05 08:33:07','2026-10-05 08:33:07'),
(37,1,2,1,3,30,NULL,NULL,0,'2026-10-05 05:33:07','2026-10-05 08:33:07','2026-10-05 08:33:07'),
(38,1,2,2,4,38,NULL,NULL,0,'2026-10-05 05:33:09','2026-10-05 08:33:09','2026-10-05 08:33:09'),
(39,1,2,1,4,38,NULL,NULL,0,'2026-10-05 05:33:10','2026-10-05 08:33:10','2026-10-05 08:33:10'),
(40,1,2,2,5,25,NULL,NULL,0,'2026-10-05 05:33:12','2026-10-05 08:33:12','2026-10-05 08:33:12'),
(41,1,2,1,5,25,NULL,NULL,0,'2026-10-05 05:33:12','2026-10-05 08:33:12','2026-10-05 08:33:12'),
(42,1,2,2,6,9,NULL,NULL,0,'2026-10-05 05:33:14','2026-10-05 08:33:14','2026-10-05 08:33:14'),
(43,1,2,1,6,24,NULL,NULL,0,'2026-10-05 05:33:15','2026-10-05 08:33:15','2026-10-05 08:33:15'),
(44,1,2,2,7,2,NULL,NULL,0,'2026-10-05 05:33:16','2026-10-05 08:33:16','2026-10-05 08:33:16'),
(45,1,2,1,7,2,NULL,NULL,0,'2026-10-05 05:33:17','2026-10-05 08:33:17','2026-10-05 08:33:17'),
(46,1,2,2,8,5,NULL,NULL,0,'2026-10-05 05:33:23','2026-10-05 08:33:23','2026-10-05 08:33:23'),
(47,1,2,1,8,5,NULL,NULL,0,'2026-10-05 05:33:24','2026-10-05 08:33:24','2026-10-05 08:33:24'),
(48,1,2,2,9,19,NULL,NULL,0,'2026-10-05 05:33:26','2026-10-05 08:33:26','2026-10-05 08:33:26'),
(49,1,2,1,9,19,NULL,NULL,0,'2026-10-05 05:33:27','2026-10-05 08:33:27','2026-10-05 08:33:27'),
(50,1,2,2,10,1,NULL,NULL,0,'2026-10-05 05:33:29','2026-10-05 08:33:29','2026-10-05 08:33:29'),
(51,1,2,1,10,16,NULL,NULL,0,'2026-10-05 05:33:30','2026-10-05 08:33:30','2026-10-05 08:33:30'),
(52,1,2,2,11,3,NULL,NULL,0,'2026-10-05 05:33:32','2026-10-05 08:33:32','2026-10-05 08:33:32'),
(53,1,2,1,11,18,NULL,NULL,0,'2026-10-05 05:33:33','2026-10-05 08:33:33','2026-10-05 08:33:33'),
(54,1,2,2,12,14,NULL,NULL,0,'2026-10-05 05:33:34','2026-10-05 08:33:34','2026-10-05 08:33:34'),
(55,1,2,1,12,14,NULL,NULL,0,'2026-10-05 05:33:35','2026-10-05 08:33:35','2026-10-05 08:33:35'),
(56,1,2,2,13,13,NULL,NULL,0,'2026-10-05 05:33:37','2026-10-05 08:33:37','2026-10-05 08:33:37'),
(57,1,2,1,13,13,NULL,NULL,0,'2026-10-05 05:33:38','2026-10-05 08:33:38','2026-10-05 08:33:38'),
(58,1,2,2,14,26,NULL,NULL,0,'2026-10-05 05:33:40','2026-10-05 08:33:40','2026-10-05 08:33:40'),
(59,1,2,1,14,41,NULL,NULL,0,'2026-10-05 05:33:41','2026-10-05 08:33:41','2026-10-05 08:33:41'),
(60,1,2,2,15,12,NULL,NULL,0,'2026-10-05 05:33:43','2026-10-05 08:33:43','2026-10-05 08:33:43'),
(61,1,2,1,15,27,NULL,NULL,0,'2026-10-05 05:33:43','2026-10-05 08:33:43','2026-10-05 08:33:43'),
(62,2,3,3,1,22,NULL,NULL,0,'2026-10-05 06:31:34','2026-10-05 09:31:34','2026-10-05 09:31:34'),
(63,2,3,4,1,22,NULL,NULL,0,'2026-10-05 06:31:36','2026-10-05 09:31:36','2026-10-05 09:31:36'),
(64,2,3,3,2,6,NULL,NULL,0,'2026-10-05 06:31:37','2026-10-05 09:31:37','2026-10-05 09:31:37'),
(65,2,3,4,2,21,NULL,NULL,0,'2026-10-05 06:31:38','2026-10-05 09:31:38','2026-10-05 09:31:38'),
(66,2,3,3,3,45,NULL,NULL,0,'2026-10-05 06:31:40','2026-10-05 09:31:40','2026-10-05 09:31:40'),
(67,2,3,4,3,30,NULL,NULL,0,'2026-10-05 06:31:41','2026-10-05 09:31:41','2026-10-05 09:31:41'),
(68,2,3,4,4,8,NULL,NULL,0,'2026-10-05 06:31:43','2026-10-05 09:31:43','2026-10-05 09:31:43'),
(69,2,3,3,4,23,NULL,NULL,0,'2026-10-05 06:31:45','2026-10-05 09:31:45','2026-10-05 09:31:45'),
(70,2,3,3,5,25,NULL,NULL,0,'2026-10-05 06:31:47','2026-10-05 09:31:47','2026-10-05 09:31:47'),
(71,2,3,4,5,25,NULL,NULL,0,'2026-10-05 06:31:48','2026-10-05 09:31:48','2026-10-05 09:31:48'),
(72,2,3,3,6,9,NULL,NULL,0,'2026-10-05 06:31:49','2026-10-05 09:31:49','2026-10-05 09:31:49'),
(73,2,3,4,6,39,NULL,NULL,0,'2026-10-05 06:31:51','2026-10-05 09:31:51','2026-10-05 09:31:51'),
(74,2,3,3,7,17,NULL,NULL,0,'2026-10-05 06:31:52','2026-10-05 09:31:52','2026-10-05 09:31:52'),
(75,2,3,4,7,2,NULL,NULL,0,'2026-10-05 06:31:53','2026-10-05 09:31:53','2026-10-05 09:31:53'),
(76,2,3,3,8,5,NULL,NULL,0,'2026-10-05 06:31:55','2026-10-05 09:31:55','2026-10-05 09:31:55'),
(77,2,3,4,8,35,NULL,NULL,0,'2026-10-05 06:31:57','2026-10-05 09:31:57','2026-10-05 09:31:57'),
(78,2,3,3,9,34,NULL,NULL,0,'2026-10-05 06:31:59','2026-10-05 09:31:59','2026-10-05 09:31:59'),
(79,2,3,4,9,19,NULL,NULL,0,'2026-10-05 06:32:00','2026-10-05 09:32:00','2026-10-05 09:32:00'),
(80,2,3,3,10,16,NULL,NULL,0,'2026-10-05 06:32:01','2026-10-05 09:32:01','2026-10-05 09:32:01'),
(81,2,3,4,10,16,NULL,NULL,0,'2026-10-05 06:32:02','2026-10-05 09:32:02','2026-10-05 09:32:02'),
(82,2,3,3,11,3,NULL,NULL,0,'2026-10-05 06:32:04','2026-10-05 09:32:04','2026-10-05 09:32:04'),
(83,2,3,4,11,3,NULL,NULL,0,'2026-10-05 06:32:04','2026-10-05 09:32:04','2026-10-05 09:32:04'),
(84,2,3,3,12,29,NULL,NULL,0,'2026-10-05 06:32:06','2026-10-05 09:32:06','2026-10-05 09:32:06'),
(85,2,3,4,12,29,NULL,NULL,0,'2026-10-05 06:32:07','2026-10-05 09:32:07','2026-10-05 09:32:07'),
(86,2,3,3,13,43,NULL,NULL,0,'2026-10-05 06:32:09','2026-10-05 09:32:09','2026-10-05 09:32:09'),
(87,2,3,4,13,43,NULL,NULL,0,'2026-10-05 06:32:09','2026-10-05 09:32:09','2026-10-05 09:32:09'),
(88,2,3,3,14,26,NULL,NULL,0,'2026-10-05 06:32:11','2026-10-05 09:32:11','2026-10-05 09:32:11'),
(89,2,3,4,14,26,NULL,NULL,0,'2026-10-05 06:32:12','2026-10-05 09:32:12','2026-10-05 09:32:12'),
(90,2,3,3,15,12,NULL,NULL,0,'2026-10-05 06:32:15','2026-10-05 09:32:15','2026-10-05 09:32:15'),
(91,2,3,4,15,27,NULL,NULL,0,'2026-10-05 06:32:16','2026-10-05 09:32:16','2026-10-05 09:32:16'),
(92,2,4,4,1,22,NULL,NULL,0,'2026-10-05 06:36:06','2026-10-05 09:36:06','2026-10-05 09:36:06'),
(93,2,4,3,1,22,NULL,NULL,0,'2026-10-05 06:36:08','2026-10-05 09:36:08','2026-10-05 09:36:08'),
(94,2,4,4,2,6,NULL,NULL,0,'2026-10-05 06:36:09','2026-10-05 09:36:09','2026-10-05 09:36:09'),
(95,2,4,3,2,21,NULL,NULL,0,'2026-10-05 06:36:10','2026-10-05 09:36:10','2026-10-05 09:36:10'),
(96,2,4,4,3,30,NULL,NULL,0,'2026-10-05 06:36:11','2026-10-05 09:36:11','2026-10-05 09:36:11'),
(97,2,4,3,3,30,NULL,NULL,0,'2026-10-05 06:36:12','2026-10-05 09:36:12','2026-10-05 09:36:12'),
(98,2,4,4,4,8,NULL,NULL,0,'2026-10-05 06:36:14','2026-10-05 09:36:14','2026-10-05 09:36:14'),
(99,2,4,3,4,38,NULL,NULL,0,'2026-10-05 06:36:15','2026-10-05 09:36:15','2026-10-05 09:36:15'),
(100,2,4,4,5,25,NULL,NULL,0,'2026-10-05 06:36:17','2026-10-05 09:36:17','2026-10-05 09:36:17'),
(101,2,4,3,5,25,NULL,NULL,0,'2026-10-05 06:36:17','2026-10-05 09:36:17','2026-10-05 09:36:17'),
(102,2,4,4,6,9,NULL,NULL,0,'2026-10-05 06:36:19','2026-10-05 09:36:19','2026-10-05 09:36:19'),
(103,2,4,3,6,9,NULL,NULL,0,'2026-10-05 06:36:20','2026-10-05 09:36:20','2026-10-05 09:36:20'),
(104,2,4,4,7,32,NULL,NULL,0,'2026-10-05 06:36:21','2026-10-05 09:36:21','2026-10-05 09:36:21'),
(105,2,4,3,7,17,NULL,NULL,0,'2026-10-05 06:36:22','2026-10-05 09:36:22','2026-10-05 09:36:22'),
(106,2,4,4,8,35,NULL,NULL,0,'2026-10-05 06:36:24','2026-10-05 09:36:24','2026-10-05 09:36:24'),
(107,2,4,3,8,20,NULL,NULL,0,'2026-10-05 06:36:24','2026-10-05 09:36:24','2026-10-05 09:36:24'),
(108,2,4,4,9,19,NULL,NULL,0,'2026-10-05 06:36:26','2026-10-05 09:36:26','2026-10-05 09:36:26'),
(109,2,4,3,9,19,NULL,NULL,0,'2026-10-05 06:36:27','2026-10-05 09:36:27','2026-10-05 09:36:27'),
(110,2,4,4,10,1,NULL,NULL,0,'2026-10-05 06:36:29','2026-10-05 09:36:29','2026-10-05 09:36:29'),
(111,2,4,3,10,1,NULL,NULL,0,'2026-10-05 06:36:30','2026-10-05 09:36:30','2026-10-05 09:36:30'),
(112,2,4,4,11,33,NULL,NULL,0,'2026-10-05 06:36:32','2026-10-05 09:36:32','2026-10-05 09:36:32'),
(113,2,4,3,11,33,NULL,NULL,0,'2026-10-05 06:36:33','2026-10-05 09:36:33','2026-10-05 09:36:33'),
(114,2,4,4,12,29,NULL,NULL,0,'2026-10-05 06:36:35','2026-10-05 09:36:35','2026-10-05 09:36:35'),
(115,2,4,3,12,44,NULL,NULL,0,'2026-10-05 06:36:36','2026-10-05 09:36:36','2026-10-05 09:36:36'),
(116,2,4,4,13,13,NULL,NULL,0,'2026-10-05 06:36:39','2026-10-05 09:36:39','2026-10-05 09:36:39'),
(117,2,4,3,13,28,NULL,NULL,0,'2026-10-05 06:36:39','2026-10-05 09:36:39','2026-10-05 09:36:39'),
(118,2,4,4,14,26,NULL,NULL,0,'2026-10-05 06:36:41','2026-10-05 09:36:41','2026-10-05 09:36:41'),
(119,2,4,3,14,26,NULL,NULL,0,'2026-10-05 06:36:42','2026-10-05 09:36:42','2026-10-05 09:36:42'),
(120,2,4,4,15,12,NULL,NULL,0,'2026-10-05 06:36:44','2026-10-05 09:36:44','2026-10-05 09:36:44'),
(121,2,4,3,15,12,NULL,NULL,0,'2026-10-05 06:36:45','2026-10-05 09:36:45','2026-10-05 09:36:45'),
(122,5,9,9,37,71,NULL,NULL,0,'2026-10-05 07:43:31','2026-10-05 10:43:31','2026-10-05 10:43:31'),
(123,5,9,10,37,72,NULL,NULL,0,'2026-10-05 07:43:33','2026-10-05 10:43:33','2026-10-05 10:43:33'),
(124,5,10,10,37,72,NULL,NULL,0,'2026-10-05 07:44:03','2026-10-05 10:44:03','2026-10-05 10:44:03'),
(125,5,10,9,37,72,NULL,NULL,0,'2026-10-05 07:44:06','2026-10-05 10:44:06','2026-10-05 10:44:06');
/*!40000 ALTER TABLE `respostas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resultado_faixas`
--

DROP TABLE IF EXISTS `resultado_faixas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resultado_faixas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `instrumento_versao_id` bigint(20) unsigned NOT NULL,
  `codigo` varchar(30) NOT NULL,
  `rotulo` varchar(60) NOT NULL,
  `minimo` decimal(5,2) NOT NULL,
  `maximo` decimal(5,2) NOT NULL,
  `ordem` int(10) unsigned NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_resultado_faixas_versao_codigo` (`instrumento_versao_id`,`codigo`),
  KEY `idx_resultado_faixas_versao_ordem` (`instrumento_versao_id`,`ordem`),
  CONSTRAINT `fk_resultado_faixas_versao` FOREIGN KEY (`instrumento_versao_id`) REFERENCES `instrumento_versoes` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `chk_resultado_faixas_limites` CHECK (`minimo` >= 0 and `maximo` <= 100 and `minimo` <= `maximo`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resultado_faixas`
--

LOCK TABLES `resultado_faixas` WRITE;
/*!40000 ALTER TABLE `resultado_faixas` DISABLE KEYS */;
INSERT INTO `resultado_faixas` VALUES
(6,1,'RUIM','Ruim',0.00,33.99,1,'2026-10-05 09:20:36','2026-10-05 09:20:36'),
(7,1,'REGULAR','Regular',34.00,66.99,2,'2026-10-05 09:20:36','2026-10-05 09:20:36'),
(8,1,'BOM','Bom',67.00,100.00,3,'2026-10-05 09:20:36','2026-10-05 09:20:36'),
(12,2,'RUIM','Ruim',0.00,33.99,1,'2026-10-05 10:03:06','2026-10-05 10:03:06'),
(13,2,'REGULAR','Regular',34.00,66.99,2,'2026-10-05 10:03:06','2026-10-05 10:03:06'),
(14,2,'BOM','Bom',67.00,100.00,3,'2026-10-05 10:03:06','2026-10-05 10:03:06'),
(15,4,'RUIM','Ruim',0.00,33.99,1,'2026-10-05 10:15:46','2026-10-05 10:15:46'),
(16,4,'REGULAR','Regular',34.00,66.99,2,'2026-10-05 10:15:46','2026-10-05 10:15:46'),
(17,4,'BOM','Bom',67.00,100.00,3,'2026-10-05 10:15:46','2026-10-05 10:15:46'),
(18,5,'RUIM','Ruim',0.00,33.99,1,'2026-10-05 10:30:46','2026-10-05 10:30:46'),
(19,5,'REGULAR','Regular',34.00,66.99,2,'2026-10-05 10:30:46','2026-10-05 10:30:46'),
(20,5,'BOM','Bom',67.00,100.00,3,'2026-10-05 10:30:46','2026-10-05 10:30:46');
/*!40000 ALTER TABLE `resultado_faixas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resultados`
--

DROP TABLE IF EXISTS `resultados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resultados` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `aplicacao_id` bigint(20) unsigned NOT NULL,
  `sentido` varchar(30) NOT NULL,
  `comparacoes_validas` int(10) unsigned NOT NULL DEFAULT 0,
  `coincidencias` int(10) unsigned NOT NULL DEFAULT 0,
  `percentual` decimal(5,2) DEFAULT NULL,
  `faixa_id` bigint(20) unsigned DEFAULT NULL,
  `faixa` varchar(60) DEFAULT NULL,
  `algoritmo_versao` varchar(30) NOT NULL,
  `calculado_em` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_resultados_aplicacao_sentido` (`aplicacao_id`,`sentido`),
  KEY `idx_resultados_faixa` (`faixa_id`),
  CONSTRAINT `fk_resultados_aplicacao` FOREIGN KEY (`aplicacao_id`) REFERENCES `aplicacoes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_resultados_faixa` FOREIGN KEY (`faixa_id`) REFERENCES `resultado_faixas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_resultados_sentido` CHECK (`sentido` in ('A_SOBRE_B','B_SOBRE_A')),
  CONSTRAINT `chk_resultados_percentual` CHECK (`percentual` is null or `percentual` >= 0 and `percentual` <= 100)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resultados`
--

LOCK TABLES `resultados` WRITE;
/*!40000 ALTER TABLE `resultados` DISABLE KEYS */;
INSERT INTO `resultados` VALUES
(1,1,'A_SOBRE_B',15,9,60.00,NULL,'Percepção com pontos de atenção','1.0','2026-10-05 05:33:46','2026-10-05 08:33:46','2026-10-05 08:33:46'),
(2,1,'B_SOBRE_A',15,2,13.33,NULL,'Percepção muito baixa','1.0','2026-10-05 05:33:46','2026-10-05 08:33:46','2026-10-05 08:33:46'),
(3,2,'A_SOBRE_B',15,8,53.33,7,'Regular','2.0','2026-10-05 06:36:47','2026-10-05 09:36:47','2026-10-05 09:36:47'),
(4,2,'B_SOBRE_A',15,6,40.00,7,'Regular','2.0','2026-10-05 06:36:47','2026-10-05 09:36:47','2026-10-05 09:36:47'),
(5,5,'A_SOBRE_B',1,1,100.00,20,'Bom','2.0','2026-10-05 07:44:10','2026-10-05 10:44:10','2026-10-05 10:44:10'),
(6,5,'B_SOBRE_A',1,0,0.00,18,'Ruim','2.0','2026-10-05 07:44:10','2026-10-05 10:44:10','2026-10-05 10:44:10');
/*!40000 ALTER TABLE `resultados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resultados_gerais`
--

DROP TABLE IF EXISTS `resultados_gerais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resultados_gerais` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `aplicacao_id` bigint(20) unsigned NOT NULL,
  `itens_validos` int(10) unsigned NOT NULL DEFAULT 0,
  `acertos_gerais` int(10) unsigned NOT NULL DEFAULT 0,
  `percentual` decimal(5,2) DEFAULT NULL,
  `faixa_id` bigint(20) unsigned DEFAULT NULL,
  `faixa` varchar(60) DEFAULT NULL,
  `algoritmo_versao` varchar(30) NOT NULL,
  `calculado_em` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_resultados_gerais_aplicacao` (`aplicacao_id`),
  KEY `idx_resultados_gerais_faixa` (`faixa_id`),
  CONSTRAINT `fk_resultados_gerais_aplicacao` FOREIGN KEY (`aplicacao_id`) REFERENCES `aplicacoes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_resultados_gerais_faixa` FOREIGN KEY (`faixa_id`) REFERENCES `resultado_faixas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_resultados_gerais_percentual` CHECK (`percentual` is null or `percentual` >= 0 and `percentual` <= 100)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resultados_gerais`
--

LOCK TABLES `resultados_gerais` WRITE;
/*!40000 ALTER TABLE `resultados_gerais` DISABLE KEYS */;
INSERT INTO `resultados_gerais` VALUES
(1,2,15,3,20.00,6,'Ruim','2.0','2026-10-05 06:36:47','2026-10-05 09:36:47','2026-10-05 09:36:47'),
(2,5,1,0,0.00,18,'Ruim','2.0','2026-10-05 07:44:10','2026-10-05 10:44:10','2026-10-05 10:44:10');
/*!40000 ALTER TABLE `resultados_gerais` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `checksum` char(64) NOT NULL,
  `applied_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `filename` (`filename`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES
(1,'001_base_dominio.sql','5640054820b28db00b5db2eea485d763382c763dda519508bb2f226c2f908bf6','2026-10-03 14:03:31'),
(2,'002_profissional_autenticacao.sql','4c348b556f7c5bef85a14f6e959809debc5c722eb1921de6c297a0a5211f5de2','2026-10-03 14:03:31'),
(3,'003_profissional_perfil.sql','077d45910728d0a9e0a61d45e48f13764647066d421f5d3062c5fe880cbe31ac','2026-10-03 21:18:34'),
(4,'004_resultados_comparacoes.sql','63a2bab5d27f02bd5a642dc96ff5be55aedc19f46ecbca3fb408e4934a20cafb','2026-10-04 17:01:38'),
(5,'005_ajustar_faixas_percentuais.sql','40b69c9d03c61626cd5ab477b4fc7847c24be4e5c90a03de60800ba1f1bd7963','2026-10-04 17:01:38'),
(6,'006_devolutivas.sql','7e6d2da7f37f1e879d831518c144dee5718b6937521a51e2b9c6fbf7dd5ebb6a','2026-10-04 19:55:45'),
(7,'007_auditoria.sql','9ac86da058a2c9ed7ffe59cb49ef28c55b8440edf3f96956aa25b8bcd7528329','2026-10-04 21:19:04'),
(8,'008_rate_limites.sql','23472e72b58ed0ed17e15ebd688da66982acbbe6947cbc8f90abc9a206d0b720','2026-10-04 21:19:04'),
(9,'009_site_institucional.sql','7039b21e0285df2ae2dfa86fc24547ee237159ace064d63d84934ea072bcc981','2026-10-05 07:25:29'),
(10,'010_resultado_geral.sql','5ff0dc98ccdadbbdd5d14158306a552d5f0c8680c51aef7a115b4fd05e55d6c6','2026-10-05 09:18:37');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `secoes`
--

DROP TABLE IF EXISTS `secoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `secoes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `instrumento_versao_id` bigint(20) unsigned NOT NULL,
  `titulo` varchar(180) NOT NULL,
  `descricao` text DEFAULT NULL,
  `ordem` int(10) unsigned NOT NULL DEFAULT 0,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_secoes_versao_ordem` (`instrumento_versao_id`,`ordem`),
  CONSTRAINT `fk_secoes_instrumento_versao` FOREIGN KEY (`instrumento_versao_id`) REFERENCES `instrumento_versoes` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `secoes`
--

LOCK TABLES `secoes` WRITE;
/*!40000 ALTER TABLE `secoes` DISABLE KEYS */;
INSERT INTO `secoes` VALUES
(1,1,'Percepção do relacionamento','Em cada área, responda separadamente: “O que eu penso” e “O que eu imagino que ele/ela pensa”. As respostas disponíveis são Bom, Regular e Fraco.',1,1,'2026-10-05 08:23:27','2026-10-05 08:23:27'),
(2,2,'Percepção de amizade','Teste seu grau de amizade',1,1,'2026-10-05 09:49:19','2026-10-05 09:49:19'),
(3,4,'Teste','teste',1,1,'2026-10-05 10:16:08','2026-10-05 10:16:08'),
(4,5,'Seção amizade','Um teste de sessão amizade',1,1,'2026-10-05 10:34:48','2026-10-05 10:34:48');
/*!40000 ALTER TABLE `secoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_blocos`
--

DROP TABLE IF EXISTS `site_blocos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_blocos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profissional_id` bigint(20) unsigned NOT NULL,
  `tipo` varchar(40) NOT NULL,
  `titulo` varchar(200) DEFAULT NULL,
  `descricao` text DEFAULT NULL,
  `conteudo` text DEFAULT NULL,
  `midia_url` varchar(1000) DEFAULT NULL,
  `texto_alternativo` varchar(255) DEFAULT NULL,
  `link_url` varchar(1000) DEFAULT NULL,
  `link_texto` varchar(120) DEFAULT NULL,
  `ordem` int(11) NOT NULL DEFAULT 0,
  `visivel` tinyint(1) NOT NULL DEFAULT 1,
  `status` varchar(20) NOT NULL DEFAULT 'ATIVO',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_site_blocos_profissional_ordem` (`profissional_id`,`status`,`visivel`,`ordem`,`id`),
  CONSTRAINT `fk_site_blocos_profissional` FOREIGN KEY (`profissional_id`) REFERENCES `profissionais` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `chk_site_blocos_status` CHECK (`status` in ('ATIVO','INATIVO')),
  CONSTRAINT `chk_site_blocos_visivel` CHECK (`visivel` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_blocos`
--

LOCK TABLES `site_blocos` WRITE;
/*!40000 ALTER TABLE `site_blocos` DISABLE KEYS */;
INSERT INTO `site_blocos` VALUES
(1,1,'APRESENTACAO','Apresentação',NULL,'Tânia Lopes Santiago\n\nEspecialista em Terapia Familiar Sistêmica, membro da Associação Paulista de Terapia Familiar, graduada em Terapia Ocupacional pela UFSCar.\nHá mais de 25 anos acompanhando famílias, casais, gestores e pessoas com ênfase em relacionamento interpessoal e resolução de conflitos.\nPalestrante em relacionamento interpessoal em organizações de ensino, órgãos públicos ou privados.\nInvisto em atualização e capacitação continuada profissional porque as instituições formadoras são \"apenas\" o ponto de partida do profissional.',NULL,NULL,NULL,NULL,10,1,'ATIVO','2026-10-05 11:03:14','2026-10-05 11:03:14'),
(2,1,'TEXTO','Família',NULL,'A família é um sistema onde cada integrante possui recursos inatos ou adquiridos que são utilizados como \"ferramentas\" para a resolução de problemas e o processo terapêutico visa auxiliar a família no descobrimento dessas \"ferramentas\" individuais e grupais, para solucionar situações conflituosas. Esta visão sistêmica de resolução de conflitos também se aplica a empresas, escolas e a equipes de trabalho em geral.',NULL,NULL,NULL,NULL,20,1,'ATIVO','2026-10-05 11:04:18','2026-10-05 11:04:18');
/*!40000 ALTER TABLE `site_blocos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vinculos`
--

DROP TABLE IF EXISTS `vinculos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vinculos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profissional_id` bigint(20) unsigned NOT NULL,
  `pessoa_a_id` bigint(20) unsigned NOT NULL,
  `pessoa_b_id` bigint(20) unsigned NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `descricao_tipo` varchar(150) DEFAULT NULL,
  `duracao_texto` varchar(100) DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'ATIVO',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_vinculos_profissional` (`profissional_id`),
  KEY `idx_vinculos_pessoa_a` (`pessoa_a_id`),
  KEY `idx_vinculos_pessoa_b` (`pessoa_b_id`),
  CONSTRAINT `fk_vinculos_pessoa_a` FOREIGN KEY (`pessoa_a_id`) REFERENCES `pessoas` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_vinculos_pessoa_b` FOREIGN KEY (`pessoa_b_id`) REFERENCES `pessoas` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_vinculos_profissional` FOREIGN KEY (`profissional_id`) REFERENCES `profissionais` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vinculos`
--

LOCK TABLES `vinculos` WRITE;
/*!40000 ALTER TABLE `vinculos` DISABLE KEYS */;
/*!40000 ALTER TABLE `vinculos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'mapa_relacional'
--

--
-- Dumping routines for database 'mapa_relacional'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-10-05  8:23:29
