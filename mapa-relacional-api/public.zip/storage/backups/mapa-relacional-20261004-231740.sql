/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.2-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: mapa_relacional
-- ------------------------------------------------------
-- Server version	11.4.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `acessos_aplicacao`
--

DROP TABLE IF EXISTS `acessos_aplicacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acessos_aplicacao` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `aplicacao_participante_id` bigint(20) unsigned NOT NULL,
  `token_hash` char(64) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'ATIVO',
  `enviado_em` datetime DEFAULT NULL,
  `primeiro_acesso_em` datetime DEFAULT NULL,
  `ultimo_acesso_em` datetime DEFAULT NULL,
  `concluido_em` datetime DEFAULT NULL,
  `revogado_em` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_acessos_participante` (`aplicacao_participante_id`),
  UNIQUE KEY `uq_acessos_token_hash` (`token_hash`),
  KEY `idx_acessos_status` (`status`),
  CONSTRAINT `fk_acessos_aplicacao_participante` FOREIGN KEY (`aplicacao_participante_id`) REFERENCES `aplicacao_participantes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acessos_aplicacao`
--

LOCK TABLES `acessos_aplicacao` WRITE;
/*!40000 ALTER TABLE `acessos_aplicacao` DISABLE KEYS */;
INSERT INTO `acessos_aplicacao` VALUES
(7,19,'5a85eb40ebc19f90bb1335c81de527e389e667b7dcdb1e6d4478f670adec2861','ATIVO','2026-10-04 11:53:35','2026-10-04 11:54:22','2026-10-04 12:00:22',NULL,NULL,'2026-10-04 14:53:33','2026-10-04 15:00:22'),
(8,20,'37c01d4a658a7787b4c23c58002e61b41ce74f6083b6e2714a41bc9c4992f12f','ATIVO','2026-10-04 11:53:35',NULL,NULL,NULL,NULL,'2026-10-04 14:53:33','2026-10-04 14:53:35'),
(9,21,'6efbea6f1dc1431d8d44565f78f6559d91184075e90147bde032bda13953b11f','ATIVO','2026-10-04 12:01:10','2026-10-04 12:01:25','2026-10-04 12:40:00',NULL,NULL,'2026-10-04 15:01:09','2026-10-04 15:40:00'),
(10,22,'409dc3a13f4b9300c1c36f11c68087f620bb74d4df9749a14adf171e47df5e46','CONCLUIDO','2026-10-04 12:01:10','2026-10-04 12:08:05','2026-10-04 14:04:55','2026-10-04 14:04:55',NULL,'2026-10-04 15:01:09','2026-10-04 17:04:55');
/*!40000 ALTER TABLE `acessos_aplicacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alternativas`
--

DROP TABLE IF EXISTS `alternativas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alternativas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` bigint(20) unsigned NOT NULL,
  `valor` varchar(100) NOT NULL,
  `rotulo` varchar(255) NOT NULL,
  `ordem` int(10) unsigned NOT NULL DEFAULT 0,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_alternativas_item_valor` (`item_id`,`valor`),
  KEY `idx_alternativas_item_ordem` (`item_id`,`ordem`),
  CONSTRAINT `fk_alternativas_item` FOREIGN KEY (`item_id`) REFERENCES `itens` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alternativas`
--

LOCK TABLES `alternativas` WRITE;
/*!40000 ALTER TABLE `alternativas` DISABLE KEYS */;
INSERT INTO `alternativas` VALUES
(1,2,'1','Nunca',1,1,'2026-10-04 09:22:33','2026-10-04 09:25:17'),
(2,2,'2','às vezes',2,1,'2026-10-04 09:23:05','2026-10-04 09:23:05'),
(3,2,'3','Frequentemente',3,1,'2026-10-04 09:23:50','2026-10-04 09:23:50');
/*!40000 ALTER TABLE `alternativas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aplicacao_itens_excluidos`
--

DROP TABLE IF EXISTS `aplicacao_itens_excluidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aplicacao_itens_excluidos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `aplicacao_id` bigint(20) unsigned NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `marcado_por_participante_id` bigint(20) unsigned NOT NULL,
  `motivo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_aplicacao_item_excluido` (`aplicacao_id`,`item_id`),
  KEY `idx_itens_excluidos_participante` (`marcado_por_participante_id`),
  KEY `fk_itens_excluidos_item` (`item_id`),
  CONSTRAINT `fk_itens_excluidos_aplicacao` FOREIGN KEY (`aplicacao_id`) REFERENCES `aplicacoes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_itens_excluidos_item` FOREIGN KEY (`item_id`) REFERENCES `itens` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_itens_excluidos_participante` FOREIGN KEY (`marcado_por_participante_id`) REFERENCES `aplicacao_participantes` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aplicacao_itens_excluidos`
--

LOCK TABLES `aplicacao_itens_excluidos` WRITE;
/*!40000 ALTER TABLE `aplicacao_itens_excluidos` DISABLE KEYS */;
/*!40000 ALTER TABLE `aplicacao_itens_excluidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aplicacao_participantes`
--

DROP TABLE IF EXISTS `aplicacao_participantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aplicacao_participantes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `aplicacao_id` bigint(20) unsigned NOT NULL,
  `pessoa_id` bigint(20) unsigned DEFAULT NULL,
  `lado` char(1) NOT NULL,
  `nome_snapshot` varchar(150) DEFAULT NULL,
  `idade_snapshot` smallint(5) unsigned DEFAULT NULL,
  `genero_snapshot` varchar(30) DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'PENDENTE',
  `iniciou_em` datetime DEFAULT NULL,
  `concluiu_em` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_aplicacao_participante_lado` (`aplicacao_id`,`lado`),
  UNIQUE KEY `uq_aplicacao_participante_pessoa` (`aplicacao_id`,`pessoa_id`),
  KEY `idx_aplicacao_participantes_pessoa` (`pessoa_id`),
  KEY `idx_aplicacao_participantes_status` (`status`),
  CONSTRAINT `fk_aplicacao_participantes_aplicacao` FOREIGN KEY (`aplicacao_id`) REFERENCES `aplicacoes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_aplicacao_participantes_pessoa` FOREIGN KEY (`pessoa_id`) REFERENCES `pessoas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_aplicacao_participantes_lado` CHECK (`lado` in ('A','B'))
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aplicacao_participantes`
--

LOCK TABLES `aplicacao_participantes` WRITE;
/*!40000 ALTER TABLE `aplicacao_participantes` DISABLE KEYS */;
INSERT INTO `aplicacao_participantes` VALUES
(1,1,1,'A','Manoel',NULL,NULL,'PENDENTE',NULL,NULL,'2026-10-04 11:31:40','2026-10-04 11:31:40'),
(2,1,2,'B','Maria',NULL,NULL,'PENDENTE',NULL,NULL,'2026-10-04 11:31:40','2026-10-04 11:31:40'),
(3,2,1,'A','Manoel',NULL,NULL,'PENDENTE',NULL,NULL,'2026-10-04 11:34:25','2026-10-04 11:34:25'),
(4,2,2,'B','Maria',NULL,NULL,'PENDENTE',NULL,NULL,'2026-10-04 11:34:25','2026-10-04 11:34:25'),
(5,3,1,'A','Manoel',NULL,NULL,'PENDENTE',NULL,NULL,'2026-10-04 11:39:29','2026-10-04 11:39:29'),
(6,3,2,'B','Maria',NULL,NULL,'PENDENTE',NULL,NULL,'2026-10-04 11:39:29','2026-10-04 11:39:29'),
(7,4,NULL,'A',NULL,NULL,NULL,'PENDENTE',NULL,NULL,'2026-10-04 11:41:01','2026-10-04 11:41:01'),
(8,4,NULL,'B',NULL,NULL,NULL,'PENDENTE',NULL,NULL,'2026-10-04 11:41:01','2026-10-04 11:41:01'),
(9,5,NULL,'A',NULL,NULL,NULL,'PENDENTE',NULL,NULL,'2026-10-04 11:44:51','2026-10-04 11:44:51'),
(10,5,NULL,'B',NULL,NULL,NULL,'PENDENTE',NULL,NULL,'2026-10-04 11:44:51','2026-10-04 11:44:51'),
(11,6,NULL,'A','João',NULL,NULL,'PENDENTE',NULL,NULL,'2026-10-04 12:13:43','2026-10-04 12:13:43'),
(12,6,NULL,'B','Maria',NULL,NULL,'PENDENTE',NULL,NULL,'2026-10-04 12:13:43','2026-10-04 12:13:43'),
(19,10,NULL,'A','João da Silva',NULL,NULL,'PENDENTE',NULL,NULL,'2026-10-04 14:53:33','2026-10-04 14:53:33'),
(20,10,NULL,'B','Maria da Silva',NULL,NULL,'PENDENTE',NULL,NULL,'2026-10-04 14:53:33','2026-10-04 14:53:33'),
(21,11,NULL,'A','Carlos',55,'Masculino','EM_ANDAMENTO','2026-10-04 12:07:20',NULL,'2026-10-04 15:01:09','2026-10-04 15:07:20'),
(22,11,NULL,'B','Maria',45,'Feminino','CONCLUIDO','2026-10-04 12:40:28','2026-10-04 14:04:55','2026-10-04 15:01:09','2026-10-04 17:04:55');
/*!40000 ALTER TABLE `aplicacao_participantes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aplicacoes`
--

DROP TABLE IF EXISTS `aplicacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aplicacoes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profissional_id` bigint(20) unsigned NOT NULL,
  `vinculo_id` bigint(20) unsigned DEFAULT NULL,
  `instrumento_versao_id` bigint(20) unsigned NOT NULL,
  `email_contato` varchar(190) NOT NULL,
  `tipo_vinculo_snapshot` varchar(50) NOT NULL,
  `duracao_vinculo_texto` varchar(100) DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'RASCUNHO',
  `enviado_em` datetime DEFAULT NULL,
  `iniciada_em` datetime DEFAULT NULL,
  `concluida_em` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_aplicacoes_profissional` (`profissional_id`),
  KEY `idx_aplicacoes_vinculo` (`vinculo_id`),
  KEY `idx_aplicacoes_versao` (`instrumento_versao_id`),
  KEY `idx_aplicacoes_email` (`email_contato`),
  KEY `idx_aplicacoes_status` (`status`),
  CONSTRAINT `fk_aplicacoes_instrumento_versao` FOREIGN KEY (`instrumento_versao_id`) REFERENCES `instrumento_versoes` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_aplicacoes_profissional` FOREIGN KEY (`profissional_id`) REFERENCES `profissionais` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_aplicacoes_vinculo` FOREIGN KEY (`vinculo_id`) REFERENCES `vinculos` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aplicacoes`
--

LOCK TABLES `aplicacoes` WRITE;
/*!40000 ALTER TABLE `aplicacoes` DISABLE KEYS */;
INSERT INTO `aplicacoes` VALUES
(1,1,2,1,'gidenilson@gmail.com','CASAL',NULL,'RASCUNHO',NULL,NULL,NULL,'2026-10-04 11:31:40','2026-10-04 11:31:40'),
(2,1,2,1,'gidenilson@gmail.com','CASAL',NULL,'RASCUNHO',NULL,NULL,NULL,'2026-10-04 11:34:25','2026-10-04 11:34:25'),
(3,1,2,1,'gidenilson@gmail.com','CASAL','15','RASCUNHO',NULL,NULL,NULL,'2026-10-04 11:39:29','2026-10-04 11:39:29'),
(4,1,NULL,1,'gidenilson@gmail.com','CASAL','8','RASCUNHO',NULL,NULL,NULL,'2026-10-04 11:41:01','2026-10-04 11:41:01'),
(5,1,NULL,1,'tanialopessantiago@gmail.com','AMIZADE','5','RASCUNHO',NULL,NULL,NULL,'2026-10-04 11:44:51','2026-10-04 11:44:51'),
(6,1,NULL,1,'gidenilson@gmail.com','CASAL','34','RASCUNHO',NULL,NULL,NULL,'2026-10-04 12:13:43','2026-10-04 12:13:43'),
(10,1,NULL,1,'gidenilson@gmail.com','CASAL','12','PRONTA','2026-10-04 11:53:35',NULL,NULL,'2026-10-04 14:53:33','2026-10-04 14:53:35'),
(11,1,NULL,1,'gidenilson@gmail.com','CASAL','12','EM_ANDAMENTO','2026-10-04 12:01:10','2026-10-04 12:07:20',NULL,'2026-10-04 15:01:09','2026-10-04 15:07:20');
/*!40000 ALTER TABLE `aplicacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comparacoes`
--

DROP TABLE IF EXISTS `comparacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comparacoes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `aplicacao_id` bigint(20) unsigned NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `sentido` varchar(30) NOT NULL,
  `resposta_percebida_id` bigint(20) unsigned DEFAULT NULL,
  `resposta_autorreferida_id` bigint(20) unsigned DEFAULT NULL,
  `comparavel` tinyint(1) NOT NULL DEFAULT 0,
  `coincide` tinyint(1) DEFAULT NULL,
  `motivo_nao_comparavel` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_comparacoes_aplicacao_item_sentido` (`aplicacao_id`,`item_id`,`sentido`),
  KEY `idx_comparacoes_aplicacao_sentido` (`aplicacao_id`,`sentido`),
  KEY `idx_comparacoes_item` (`item_id`),
  KEY `idx_comparacoes_resposta_percebida` (`resposta_percebida_id`),
  KEY `idx_comparacoes_resposta_autorreferida` (`resposta_autorreferida_id`),
  CONSTRAINT `fk_comparacoes_aplicacao` FOREIGN KEY (`aplicacao_id`) REFERENCES `aplicacoes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_comparacoes_item` FOREIGN KEY (`item_id`) REFERENCES `itens` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_comparacoes_resposta_autorreferida` FOREIGN KEY (`resposta_autorreferida_id`) REFERENCES `respostas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_comparacoes_resposta_percebida` FOREIGN KEY (`resposta_percebida_id`) REFERENCES `respostas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_comparacoes_sentido` CHECK (`sentido` in ('A_SOBRE_B','B_SOBRE_A')),
  CONSTRAINT `chk_comparacoes_coincide` CHECK (`coincide` is null or `coincide` in (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comparacoes`
--

LOCK TABLES `comparacoes` WRITE;
/*!40000 ALTER TABLE `comparacoes` DISABLE KEYS */;
/*!40000 ALTER TABLE `comparacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devolutivas`
--

DROP TABLE IF EXISTS `devolutivas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devolutivas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `aplicacao_id` bigint(20) unsigned NOT NULL,
  `profissional_id` bigint(20) unsigned NOT NULL,
  `sintese` text DEFAULT NULL,
  `observacoes` text DEFAULT NULL,
  `comentario_profissional` text DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'RASCUNHO',
  `token_hash` char(64) DEFAULT NULL,
  `liberada_em` datetime DEFAULT NULL,
  `enviado_em` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_devolutivas_aplicacao` (`aplicacao_id`),
  UNIQUE KEY `uq_devolutivas_token_hash` (`token_hash`),
  KEY `idx_devolutivas_profissional_status` (`profissional_id`,`status`),
  CONSTRAINT `fk_devolutivas_aplicacao` FOREIGN KEY (`aplicacao_id`) REFERENCES `aplicacoes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_devolutivas_profissional` FOREIGN KEY (`profissional_id`) REFERENCES `profissionais` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `chk_devolutivas_status` CHECK (`status` in ('RASCUNHO','LIBERADA'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devolutivas`
--

LOCK TABLES `devolutivas` WRITE;
/*!40000 ALTER TABLE `devolutivas` DISABLE KEYS */;
/*!40000 ALTER TABLE `devolutivas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instrumento_versoes`
--

DROP TABLE IF EXISTS `instrumento_versoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instrumento_versoes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `instrumento_id` bigint(20) unsigned NOT NULL,
  `numero_versao` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'RASCUNHO',
  `publicado_em` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_instrumento_versao` (`instrumento_id`,`numero_versao`),
  KEY `idx_instrumento_versoes_status` (`status`),
  CONSTRAINT `fk_instrumento_versoes_instrumento` FOREIGN KEY (`instrumento_id`) REFERENCES `instrumentos` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instrumento_versoes`
--

LOCK TABLES `instrumento_versoes` WRITE;
/*!40000 ALTER TABLE `instrumento_versoes` DISABLE KEYS */;
INSERT INTO `instrumento_versoes` VALUES
(1,2,'1.0','PUBLICADA','2026-10-04 04:52:10','2026-10-04 07:51:47','2026-10-04 07:52:10'),
(3,2,'2','RASCUNHO',NULL,'2026-10-04 09:14:01','2026-10-04 09:14:01');
/*!40000 ALTER TABLE `instrumento_versoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instrumentos`
--

DROP TABLE IF EXISTS `instrumentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instrumentos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profissional_id` bigint(20) unsigned NOT NULL,
  `nome` varchar(180) NOT NULL,
  `descricao` text DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'RASCUNHO',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_instrumentos_profissional` (`profissional_id`),
  KEY `idx_instrumentos_status` (`status`),
  CONSTRAINT `fk_instrumentos_profissional` FOREIGN KEY (`profissional_id`) REFERENCES `profissionais` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instrumentos`
--

LOCK TABLES `instrumentos` WRITE;
/*!40000 ALTER TABLE `instrumentos` DISABLE KEYS */;
INSERT INTO `instrumentos` VALUES
(2,1,'Avaliação de comunicação','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since 1966, when designers at Letraset and James Mosley,','ATIVO','2026-10-04 07:51:26','2026-10-04 12:12:05');
/*!40000 ALTER TABLE `instrumentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `itens`
--

DROP TABLE IF EXISTS `itens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `itens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `secao_id` bigint(20) unsigned NOT NULL,
  `codigo` varchar(80) NOT NULL,
  `texto` text NOT NULL,
  `tipo_resposta` varchar(40) NOT NULL,
  `ordem` int(10) unsigned NOT NULL DEFAULT 0,
  `permite_nao_se_aplica` tinyint(1) NOT NULL DEFAULT 0,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_itens_secao_codigo` (`secao_id`,`codigo`),
  KEY `idx_itens_secao_ordem` (`secao_id`,`ordem`),
  CONSTRAINT `fk_itens_secao` FOREIGN KEY (`secao_id`) REFERENCES `secoes` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itens`
--

LOCK TABLES `itens` WRITE;
/*!40000 ALTER TABLE `itens` DISABLE KEYS */;
INSERT INTO `itens` VALUES
(2,2,'com01','Sinto que consigo expressar claramente o que penso e sinto para a outra pessoa.','ESCOLHA_UNICA',1,1,1,'2026-10-04 09:20:28','2026-10-04 09:20:28');
/*!40000 ALTER TABLE `itens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pessoas`
--

DROP TABLE IF EXISTS `pessoas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pessoas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profissional_id` bigint(20) unsigned NOT NULL,
  `nome` varchar(150) NOT NULL,
  `email` varchar(190) DEFAULT NULL,
  `telefone` varchar(30) DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `observacao_administrativa` text DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'ATIVO',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_pessoas_profissional` (`profissional_id`),
  KEY `idx_pessoas_email` (`email`),
  KEY `idx_pessoas_status` (`status`),
  CONSTRAINT `fk_pessoas_profissional` FOREIGN KEY (`profissional_id`) REFERENCES `profissionais` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pessoas`
--

LOCK TABLES `pessoas` WRITE;
/*!40000 ALTER TABLE `pessoas` DISABLE KEYS */;
INSERT INTO `pessoas` VALUES
(1,1,'Manoel','manoel@gmail.com',NULL,NULL,NULL,'ATIVO','2026-10-04 09:47:01','2026-10-04 09:47:01'),
(2,1,'Maria','maria@gmail.com',NULL,NULL,NULL,'ATIVO','2026-10-04 09:47:26','2026-10-04 09:47:26');
/*!40000 ALTER TABLE `pessoas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profissionais`
--

DROP TABLE IF EXISTS `profissionais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profissionais` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) NOT NULL,
  `email` varchar(190) NOT NULL,
  `senha_hash` varchar(255) DEFAULT NULL,
  `telefone` varchar(30) DEFAULT NULL,
  `descricao` text DEFAULT NULL,
  `atuacao` text DEFAULT NULL,
  `foto_url` varchar(500) DEFAULT NULL,
  `logo_url` varchar(500) DEFAULT NULL,
  `dados_contato` text DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'ATIVO',
  `senha_alterada_em` datetime DEFAULT NULL,
  `ultimo_login_em` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_profissionais_email` (`email`),
  KEY `idx_profissionais_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profissionais`
--

LOCK TABLES `profissionais` WRITE;
/*!40000 ALTER TABLE `profissionais` DISABLE KEYS */;
INSERT INTO `profissionais` VALUES
(1,'Tânia Lopes Santiago','tanialopessantiago@gmail.com','$2y$10$iefrgyU6jbBxU9bQWKSsaOKHAPeuOcG5O1SL7ahSX/hf8lkoT2RTy','16997119152','====Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse bibendum gravida ornare. Aenean rhoncus eget velit quis pharetra. Duis tempus, nisi ac pretium lobortis, velit metus vehicula ex, ut cursus lacus nisl vel erat. Maecenas convallis purus venenatis, dapibus erat id, ultrices purus. In ultrices risus sit amet ante placerat, quis vehicula nisi gravida. Pellentesque bibendum pellentesque imperdiet. Integer auctor a ligula pulvinar cursus.','Fusce ut tortor vel tortor fermentum semper. Cras imperdiet blandit ante nec rhoncus. Donec scelerisque iaculis pulvinar. Integer maximus convallis tellus nec posuere. Etiam mattis blandit commodo.',NULL,NULL,'Nunc dapibus condimentum nibh id sodales. Vestibulum et augue magna. Praesent id laoreet dui. Proin et justo arcu. Integer ut neque vestibulum, laoreet lectus ut, volutpat dolor.','ATIVO','2026-10-03 19:18:54','2026-10-04 17:13:53','2026-10-03 16:00:21','2026-10-04 20:13:53');
/*!40000 ALTER TABLE `profissionais` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `respostas`
--

DROP TABLE IF EXISTS `respostas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `respostas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `aplicacao_id` bigint(20) unsigned NOT NULL,
  `respondente_id` bigint(20) unsigned NOT NULL,
  `alvo_id` bigint(20) unsigned NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `alternativa_id` bigint(20) unsigned DEFAULT NULL,
  `valor_texto` text DEFAULT NULL,
  `valor_numero` decimal(18,6) DEFAULT NULL,
  `nao_se_aplica` tinyint(1) NOT NULL DEFAULT 0,
  `respondido_em` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_resposta_contexto` (`aplicacao_id`,`respondente_id`,`alvo_id`,`item_id`),
  KEY `idx_respostas_aplicacao_item` (`aplicacao_id`,`item_id`),
  KEY `idx_respostas_respondente` (`respondente_id`),
  KEY `idx_respostas_alvo` (`alvo_id`),
  KEY `idx_respostas_alternativa` (`alternativa_id`),
  KEY `fk_respostas_item` (`item_id`),
  CONSTRAINT `fk_respostas_alternativa` FOREIGN KEY (`alternativa_id`) REFERENCES `alternativas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_respostas_alvo` FOREIGN KEY (`alvo_id`) REFERENCES `aplicacao_participantes` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_respostas_aplicacao` FOREIGN KEY (`aplicacao_id`) REFERENCES `aplicacoes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_respostas_item` FOREIGN KEY (`item_id`) REFERENCES `itens` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_respostas_respondente` FOREIGN KEY (`respondente_id`) REFERENCES `aplicacao_participantes` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `respostas`
--

LOCK TABLES `respostas` WRITE;
/*!40000 ALTER TABLE `respostas` DISABLE KEYS */;
/*!40000 ALTER TABLE `respostas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resultado_faixas`
--

DROP TABLE IF EXISTS `resultado_faixas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resultado_faixas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `instrumento_versao_id` bigint(20) unsigned NOT NULL,
  `codigo` varchar(30) NOT NULL,
  `rotulo` varchar(60) NOT NULL,
  `minimo` decimal(5,2) NOT NULL,
  `maximo` decimal(5,2) NOT NULL,
  `ordem` int(10) unsigned NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_resultado_faixas_versao_codigo` (`instrumento_versao_id`,`codigo`),
  KEY `idx_resultado_faixas_versao_ordem` (`instrumento_versao_id`,`ordem`),
  CONSTRAINT `fk_resultado_faixas_versao` FOREIGN KEY (`instrumento_versao_id`) REFERENCES `instrumento_versoes` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `chk_resultado_faixas_limites` CHECK (`minimo` >= 0 and `maximo` <= 100 and `minimo` <= `maximo`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resultado_faixas`
--

LOCK TABLES `resultado_faixas` WRITE;
/*!40000 ALTER TABLE `resultado_faixas` DISABLE KEYS */;
INSERT INTO `resultado_faixas` VALUES
(1,1,'RUIM','Ruim',0.00,33.99,1,'2026-10-04 17:01:38','2026-10-04 17:01:38'),
(2,3,'RUIM','Ruim',0.00,33.99,1,'2026-10-04 17:01:38','2026-10-04 17:01:38'),
(3,1,'REGULAR','Regular',34.00,66.99,2,'2026-10-04 17:01:38','2026-10-04 17:01:38'),
(4,3,'REGULAR','Regular',34.00,66.99,2,'2026-10-04 17:01:38','2026-10-04 17:01:38'),
(5,1,'BOM','Bom',67.00,100.00,3,'2026-10-04 17:01:38','2026-10-04 17:01:38'),
(6,3,'BOM','Bom',67.00,100.00,3,'2026-10-04 17:01:38','2026-10-04 17:01:38');
/*!40000 ALTER TABLE `resultado_faixas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resultados`
--

DROP TABLE IF EXISTS `resultados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resultados` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `aplicacao_id` bigint(20) unsigned NOT NULL,
  `sentido` varchar(30) NOT NULL,
  `comparacoes_validas` int(10) unsigned NOT NULL DEFAULT 0,
  `coincidencias` int(10) unsigned NOT NULL DEFAULT 0,
  `percentual` decimal(5,2) DEFAULT NULL,
  `faixa_id` bigint(20) unsigned DEFAULT NULL,
  `faixa` varchar(60) DEFAULT NULL,
  `algoritmo_versao` varchar(30) NOT NULL,
  `calculado_em` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_resultados_aplicacao_sentido` (`aplicacao_id`,`sentido`),
  KEY `idx_resultados_faixa` (`faixa_id`),
  CONSTRAINT `fk_resultados_aplicacao` FOREIGN KEY (`aplicacao_id`) REFERENCES `aplicacoes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_resultados_faixa` FOREIGN KEY (`faixa_id`) REFERENCES `resultado_faixas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_resultados_sentido` CHECK (`sentido` in ('A_SOBRE_B','B_SOBRE_A')),
  CONSTRAINT `chk_resultados_percentual` CHECK (`percentual` is null or `percentual` >= 0 and `percentual` <= 100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resultados`
--

LOCK TABLES `resultados` WRITE;
/*!40000 ALTER TABLE `resultados` DISABLE KEYS */;
/*!40000 ALTER TABLE `resultados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `checksum` char(64) NOT NULL,
  `applied_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `filename` (`filename`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES
(1,'001_base_dominio.sql','5640054820b28db00b5db2eea485d763382c763dda519508bb2f226c2f908bf6','2026-10-03 14:03:31'),
(2,'002_profissional_autenticacao.sql','4c348b556f7c5bef85a14f6e959809debc5c722eb1921de6c297a0a5211f5de2','2026-10-03 14:03:31'),
(3,'003_profissional_perfil.sql','077d45910728d0a9e0a61d45e48f13764647066d421f5d3062c5fe880cbe31ac','2026-10-03 21:18:34'),
(4,'004_resultados_comparacoes.sql','63a2bab5d27f02bd5a642dc96ff5be55aedc19f46ecbca3fb408e4934a20cafb','2026-10-04 17:01:38'),
(5,'005_ajustar_faixas_percentuais.sql','40b69c9d03c61626cd5ab477b4fc7847c24be4e5c90a03de60800ba1f1bd7963','2026-10-04 17:01:38'),
(6,'006_devolutivas.sql','7e6d2da7f37f1e879d831518c144dee5718b6937521a51e2b9c6fbf7dd5ebb6a','2026-10-04 19:55:45');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `secoes`
--

DROP TABLE IF EXISTS `secoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `secoes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `instrumento_versao_id` bigint(20) unsigned NOT NULL,
  `titulo` varchar(180) NOT NULL,
  `descricao` text DEFAULT NULL,
  `ordem` int(10) unsigned NOT NULL DEFAULT 0,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_secoes_versao_ordem` (`instrumento_versao_id`,`ordem`),
  CONSTRAINT `fk_secoes_instrumento_versao` FOREIGN KEY (`instrumento_versao_id`) REFERENCES `instrumento_versoes` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `secoes`
--

LOCK TABLES `secoes` WRITE;
/*!40000 ALTER TABLE `secoes` DISABLE KEYS */;
INSERT INTO `secoes` VALUES
(2,3,'Comunicação','Percepção sobre clareza, abertura e compreensão na comunicação entre os participantes.',1,1,'2026-10-04 09:17:30','2026-10-04 09:17:30');
/*!40000 ALTER TABLE `secoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vinculos`
--

DROP TABLE IF EXISTS `vinculos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vinculos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profissional_id` bigint(20) unsigned NOT NULL,
  `pessoa_a_id` bigint(20) unsigned NOT NULL,
  `pessoa_b_id` bigint(20) unsigned NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `descricao_tipo` varchar(150) DEFAULT NULL,
  `duracao_texto` varchar(100) DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'ATIVO',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_vinculos_profissional` (`profissional_id`),
  KEY `idx_vinculos_pessoa_a` (`pessoa_a_id`),
  KEY `idx_vinculos_pessoa_b` (`pessoa_b_id`),
  CONSTRAINT `fk_vinculos_pessoa_a` FOREIGN KEY (`pessoa_a_id`) REFERENCES `pessoas` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_vinculos_pessoa_b` FOREIGN KEY (`pessoa_b_id`) REFERENCES `pessoas` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_vinculos_profissional` FOREIGN KEY (`profissional_id`) REFERENCES `profissionais` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vinculos`
--

LOCK TABLES `vinculos` WRITE;
/*!40000 ALTER TABLE `vinculos` DISABLE KEYS */;
INSERT INTO `vinculos` VALUES
(2,1,1,2,'CASAL',NULL,'15','ATIVO','2026-10-04 09:49:37','2026-10-04 11:38:25');
/*!40000 ALTER TABLE `vinculos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'mapa_relacional'
--

--
-- Dumping routines for database 'mapa_relacional'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-10-04 18:17:40
